# Ethiopia Events — Android app foundation (v0.2.1)

A native Android application built with Kotlin and Jetpack Compose. One installation supports both ticket buyers and event organisers.

## Current state

The current screens are a navigable prototype. Event listings are sample data; saved events and organiser drafts are local preview state. No real account, event catalogue, order, payment, refund, ticket issuance, QR validation, organiser approval, payout, or entry-scanning service is connected. Do not use the current build to sell or validate real tickets.

## Android compatibility

- Minimum SDK: API 24 (Android 7.0 Nougat)
- Target SDK: API 36 (Android 16)
- Compile SDK: API 37
- Adaptive launcher icons: Android 8.0+; legacy density icons are included for Android 7.0/7.1.

This configuration declares compatibility from Android 7.0 onward. It is not a substitute for testing on physical/emulated API 24, 25, and the newer supported versions.

## Build toolchain

- Android Gradle Plugin 9.1.1
- Gradle 9.3.1
- JDK 17
- Kotlin Compose compiler plugin 2.2.10
- Compose BOM 2026.09.00
- Application ID: `et.events.mobile`

## Debug and release builds

The GitHub Actions workflow can always create a debug APK for internal testing. A signed release APK and Android App Bundle (`.aab`) are produced only after the repository has these GitHub Actions secrets configured:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

The keystore is the app's long-term upload-signing identity. Keep a private backup outside GitHub. Never commit the `.jks` file or expose its password in the repository or workflow logs. Do not generate a replacement key after publishing; losing the key can complicate future updates.

## Backend and payment production gates

Real ticketing requires a deployed backend, database, Row Level Security policies, authenticated accounts, server-created orders, inventory holds, server-side payment initialization and verification, webhook signature/amount/reference checks, ticket generation, atomic check-in, refunds and audit records. The Android client must never contain a Chapa secret key or decide that a payment succeeded based on a browser return page or screenshot.

The planned first backend is Supabase. Hosted checkout with an authorised Ethiopian payment provider (initial candidate: Chapa) should be wired through server-side functions. Start in provider test mode. Live payments require an approved merchant account and live API credentials.

## Product and brand

The first-launch role choices are retained. Red `#B82035` and warm ivory `#F7F1E7` remain the brand colours. The original user-approved launcher mark is restored: an ivory ticket silhouette on the brand-red field, with a perforation line. The label “Events” and application ID remain provisional until the final public brand name is chosen.
