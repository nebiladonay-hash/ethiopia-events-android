# Ethiopia Events — product and security specification

## Product structure

One native Android app with role-based access. A person may be both a buyer and an organiser; organiser capabilities are granted only after server-side verification. Entry staff receive a restricted scanner role.

## Brand

- Primary red: `#B82035`
- Warm ivory: `#F7F1E7`
- Main text: `#2B2020`
- Supporting text: `#8C7771`
- Launcher mark: restored original ivory ticket silhouette with a perforation line on the brand-red field; preserve this user-approved mark.

## Android platform

- Minimum API 24 (Android 7.0)
- Target API 36 (Android 16)
- Compile API 37
- Legacy density launcher assets included for API 24/25.

## Buyer experience

Discovery, search, categories, event details, saved events, ticket-type selection, order checkout, payment status, issued tickets, QR display, order history, cancellation/refund status and profile.

## Organiser experience

Organiser verification, event draft creation, image upload, ticket types, capacity, sale windows, event publication, order/attendee list, sales reporting, refunds and check-in staff management.

## Transaction invariants

1. The server owns ticket inventory and prices. The client never decides final payable totals.
2. Create a short-lived inventory hold transactionally before redirecting to payment.
3. Create payment requests only on the server; provider secret keys never ship in the app.
4. Mark an order paid only after server-to-server provider verification and validated webhook processing. Validate merchant, amount, currency, reference, status and idempotency.
5. Issue tickets only once for a confirmed paid order. Use unpredictable ticket tokens, never sequential ticket IDs.
6. Check-in is an atomic server-side state transition. A second scan must be rejected.
7. Expire abandoned holds and release capacity. Keep payment, order and ticket audit logs.
8. Refunds and charge reversals change ticket validity according to explicit policies.

## Backend plan

Supabase Auth, Postgres, Storage and Edge Functions. Apply Row Level Security to profiles, organiser records, events, ticket types, orders, tickets, check-ins and payouts. Public users can read only published, approved event listings. Buyers can read their own orders/tickets. Organisers can manage only their verified organisations and owned event records. Staff can check in only events they are assigned to.

## Payment plan

Start with hosted checkout in Chapa test mode, subject to merchant eligibility and API access. Mobile app requests checkout from a trusted backend function. Backend creates the provider transaction, stores a pending payment, then returns only the checkout URL/reference. A provider webhook plus server-side verify call confirms payment. Live keys and webhook secrets belong in Supabase secrets, not Android or GitHub client code.

## Release readiness gates

- Build and install debug on API 24, 25, 26, 28, 30, 33, 34 and API 36 devices/emulators.
- Exercise rotation, process death, poor connectivity, duplicate taps and payment return handling.
- Use a private upload keystore with a verified backup. Sign APK/AAB in CI using GitHub Actions secrets.
- Test provider sandbox flows (success, failure, timeout, duplicate webhook, wrong amount, wrong reference, cancelled checkout).
- Complete privacy policy, data-safety disclosures, refund/contact policies, organiser terms and store listing before public release.
