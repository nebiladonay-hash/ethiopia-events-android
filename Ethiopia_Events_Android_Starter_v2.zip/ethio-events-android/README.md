# Ethiopia Events — Android starter

A native Android application starter built with Kotlin and Jetpack Compose. It is one app with two roles:

- Ticket buyer
- Event organiser

## Current prototype screens

- First-launch role selection (the role is remembered; it can be switched from Account)
- Buyer: Discover, Tickets, Saved, Account
- Buyer event details with ticket quantity and a preview checkout notice
- Organiser: Overview, Events, Create, Account
- Local event draft form
- Red / warm-ivory visual system

## Important status

This is a UI prototype, not a live ticketing service. The sample events and ETB prices are demonstration data. Authentication, Supabase, payment processing, real ticket issuance, QR validation, camera scanning, organiser verification, refunds and payouts are not connected yet. No real ticket can be purchased in this build.

## Build an APK with GitHub Actions

1. Create a new GitHub repository for this app.
2. Upload the contents of this folder to the repository root (not the outer ZIP folder).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and choose **Run workflow**.
5. When the run finishes successfully, open the run, scroll to **Artifacts**, and download `events-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
7. Install the APK on an Android phone. Android may ask you to allow installation from the browser or file manager you used.

The workflow builds a debug APK for testing. It is not a signed release build for Google Play.

## Technical configuration

- Kotlin + Jetpack Compose
- Android Gradle Plugin 9.1.1
- Gradle 9.3.1
- JDK 17
- Compile SDK 37; target SDK 35; minimum SDK 26
- Compose BOM 2026.09.00
- Application ID: `et.events.mobile`

## Next implementation stage

1. Choose the final app name and package identity.
2. Create the Supabase project and database tables for profiles, organisers, venues, events, ticket types, orders, tickets and check-ins.
3. Add authentication and role permissions.
4. Connect a locally supported payment gateway. Tickets must only be issued after server-side payment confirmation.
5. Add secure QR ticket generation and duplicate-resistant scanning, including an offline check-in workflow.

The visible wordmark `EVENTS` and Android launcher label `Events` are placeholders until the final app name is chosen.

## Brand tokens

- Primary red: `#B82035`
- Warm ivory: `#F7F1E7`
- Main text: `#2B2020`
- Supporting text: `#8C7771`

Red and ivory are the two brand colours. The darker and muted tones are text neutrals for readability.
