# Product direction

## Product structure

One native Android application. On first launch, the user chooses one of two paths:

- I'm here to discover and book events.
- I'm here to organise events.

The chosen view opens on later launches. The Account area lets a user switch paths. This is one application and one codebase, not two separately installed apps.

## Buyer screens in the first UI pass

- Discover: search, event categories, featured listing and event list.
- Event details: event information, ticket quantity and total preview.
- Tickets: upcoming/past ticket area placeholder.
- Saved: bookmarked event list.
- Profile: account placeholder and role switch.

## Organiser screens in the first UI pass

- Overview: event draft count and create-event action.
- Events: drafts created in the current preview session.
- Create: event name, venue, date and starting ticket price.
- Account: role switch.

## Visual direction

- Primary red: `#B82035`
- Warm ivory: `#F7F1E7`
- Main text: `#2B2020`
- Supporting text: `#8C7771`
- Minimal copy, strong spacing, restrained borders, rounded but not overly soft controls.
- Avoid gradients as a default treatment, loud shadows, decorative clutter and extra accent colours.

## Production rules for the next build

- Use the same app and identity for both roles.
- Organiser privileges must be verified before paid events can be published.
- Do not issue tickets from client-side payment screenshots or unverified callbacks.
- Issue tickets only after server-side payment confirmation from an authorised gateway.
- Give every ticket a non-sequential, hard-to-guess token; validate it server-side and atomically mark it as checked in to prevent duplicate entry.
- Make organiser, staff and attendee permissions explicit in database policies.
- Design check-in to support an authorised offline attendee list with later sync, once online ticket validation exists.
