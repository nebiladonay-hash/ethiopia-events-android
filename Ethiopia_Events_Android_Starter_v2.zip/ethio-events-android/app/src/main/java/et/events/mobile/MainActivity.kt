package et.events.mobile

import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BrandRed = Color(0xFFB82035)
private val BrandIvory = Color(0xFFF7F1E7)
private val Ink = Color(0xFF2B2020)
private val Muted = Color(0xFF8C7771)
private val Hairline = Color(0xFFE6D9CB)
private val SoftIvory = Color(0xFFFFFBF5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(247, 241, 231)
        window.navigationBarColor = android.graphics.Color.rgb(247, 241, 231)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val preferences = getSharedPreferences("events_preferences", MODE_PRIVATE)
        setContent {
            EventsTheme {
                var role by remember { mutableStateOf(preferences.getString("role", null)) }
                EventsRoot(
                    role = role,
                    onChooseRole = { selected ->
                        role = selected
                        preferences.edit().putString("role", selected).apply()
                    }
                )
            }
        }
    }
}

@Composable
private fun EventsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = BrandRed,
            onPrimary = BrandIvory,
            secondary = BrandRed,
            onSecondary = BrandIvory,
            background = BrandIvory,
            onBackground = Ink,
            surface = SoftIvory,
            onSurface = Ink,
            outline = Hairline
        ),
        content = content
    )
}

@Composable
private fun EventsRoot(role: String?, onChooseRole: (String) -> Unit) {
    when (role) {
        "buyer" -> BuyerApp(onSwitchRole = { onChooseRole("organizer") })
        "organizer" -> OrganizerApp(onSwitchRole = { onChooseRole("buyer") })
        else -> RoleChooser(onChoose = onChooseRole)
    }
}

@Composable
private fun BrandStamp() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Box(
            modifier = Modifier
                .size(11.dp)
                .clip(CircleShape)
                .background(BrandRed)
        )
        Text(
            text = "EVENTS",
            color = BrandRed,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 3.sp
        )
    }
}

@Composable
private fun RoleChooser(onChoose: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandIvory)
            .systemBarsPadding()
            .padding(horizontal = 24.dp, vertical = 25.dp)
    ) {
        BrandStamp()
        Spacer(Modifier.weight(1f))
        RoleCard(
            label = "I'm here to discover and book events.",
            isBuyer = true,
            onClick = { onChoose("buyer") }
        )
        Spacer(Modifier.height(13.dp))
        RoleCard(
            label = "I'm here to organise events.",
            isBuyer = false,
            onClick = { onChoose("organizer") }
        )
        Spacer(Modifier.weight(1.15f))
    }
}

@Composable
private fun RoleCard(label: String, isBuyer: Boolean, onClick: () -> Unit) {
    val background = if (isBuyer) BrandRed else BrandIvory
    val foreground = if (isBuyer) BrandIvory else BrandRed
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(133.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(background)
            .then(
                if (isBuyer) Modifier else Modifier.border(1.4.dp, BrandRed, RoundedCornerShape(22.dp))
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 21.dp, vertical = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                color = foreground,
                fontSize = 17.sp,
                lineHeight = 23.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f).padding(end = 14.dp)
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TicketMark(color = foreground, modifier = Modifier.size(37.dp))
                Text("↗", color = foreground, fontSize = 19.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun TicketMark(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val left = size.width * 0.12f
        val top = size.height * 0.21f
        val width = size.width * 0.76f
        val height = size.height * 0.58f
        drawRoundRect(
            color = color,
            topLeft = Offset(left, top),
            size = Size(width, height),
            cornerRadius = CornerRadius(5.dp.toPx()),
            style = Stroke(width = 1.7.dp.toPx())
        )
        drawLine(
            color = color,
            start = Offset(size.width * 0.5f, top + 2.dp.toPx()),
            end = Offset(size.width * 0.5f, top + height - 2.dp.toPx()),
            strokeWidth = 1.4.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 3.dp.toPx()))
        )
    }
}

private data class DemoEvent(
    val id: Int,
    val title: String,
    val category: String,
    val date: String,
    val venue: String,
    val price: Int,
    val tag: String
)

private val sampleEvents = listOf(
    DemoEvent(1, "Live Music Session", "Music", "FRI · 20 NOV", "Addis Ababa · Venue TBA", 450, "SAMPLE"),
    DemoEvent(2, "Stand-up Night", "Comedy", "SAT · 21 NOV", "Addis Ababa · Venue TBA", 300, "SAMPLE"),
    DemoEvent(3, "Culture & Food Festival", "Culture", "SUN · 22 NOV", "Addis Ababa · Venue TBA", 250, "SAMPLE"),
    DemoEvent(4, "Electronic Night", "Nightlife", "SAT · 28 NOV", "Addis Ababa · Venue TBA", 600, "SAMPLE")
)

private enum class BuyerTab(val label: String) {
    DISCOVER("Discover"), TICKETS("Tickets"), SAVED("Saved"), PROFILE("Profile")
}

@Composable
private fun BuyerApp(onSwitchRole: () -> Unit) {
    var selectedTab by remember { mutableStateOf(BuyerTab.DISCOVER) }
    var search by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedEvent by remember { mutableStateOf<DemoEvent?>(null) }
    var savedIds by remember { mutableStateOf(setOf<Int>()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandIvory)
            .systemBarsPadding()
    ) {
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (selectedEvent != null) {
                EventDetailScreen(
                    event = selectedEvent!!,
                    isSaved = savedIds.contains(selectedEvent!!.id),
                    onBack = { selectedEvent = null },
                    onToggleSaved = {
                        val id = selectedEvent!!.id
                        savedIds = if (savedIds.contains(id)) savedIds - id else savedIds + id
                    }
                )
            } else {
                when (selectedTab) {
                    BuyerTab.DISCOVER -> DiscoverScreen(
                        search = search,
                        onSearchChange = { search = it },
                        selectedCategory = selectedCategory,
                        onCategoryChange = { selectedCategory = it },
                        savedIds = savedIds,
                        onOpenEvent = { selectedEvent = it },
                        onToggleSaved = { event ->
                            savedIds = if (savedIds.contains(event.id)) savedIds - event.id else savedIds + event.id
                        }
                    )
                    BuyerTab.TICKETS -> TicketsScreen()
                    BuyerTab.SAVED -> SavedScreen(
                        savedEvents = sampleEvents.filter { savedIds.contains(it.id) },
                        onOpenEvent = { selectedEvent = it },
                        onToggleSaved = { event -> savedIds = savedIds - event.id }
                    )
                    BuyerTab.PROFILE -> AccountScreen(
                        roleLabel = "Ticket buyer",
                        switchLabel = "Switch to organiser",
                        onSwitchRole = onSwitchRole
                    )
                }
            }
        }
        if (selectedEvent == null) {
            BottomBar(
                items = BuyerTab.entries.map { it.label },
                selected = selectedTab.label,
                onSelect = { label -> selectedTab = BuyerTab.entries.first { it.label == label } }
            )
        }
    }
}

@Composable
private fun DiscoverScreen(
    search: String,
    onSearchChange: (String) -> Unit,
    selectedCategory: String,
    onCategoryChange: (String) -> Unit,
    savedIds: Set<Int>,
    onOpenEvent: (DemoEvent) -> Unit,
    onToggleSaved: (DemoEvent) -> Unit
) {
    val categories = listOf("All", "Music", "Comedy", "Culture", "Nightlife")
    val filtered = sampleEvents.filter { event ->
        (selectedCategory == "All" || event.category == selectedCategory) &&
            (search.isBlank() || event.title.contains(search, ignoreCase = true) || event.category.contains(search, ignoreCase = true))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandIvory)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScrollCompat()
                .padding(horizontal = 21.dp)
        ) {
            Spacer(Modifier.height(19.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                BrandStamp()
                Text(
                    text = "ADDIS ABABA  ·  ETH",
                    color = Muted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.1.sp
                )
            }
            Spacer(Modifier.height(25.dp))
            Text("Discover", color = Ink, fontSize = 31.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp)
            Spacer(Modifier.height(14.dp))
            SearchField(value = search, onValueChange = onSearchChange)
            Spacer(Modifier.height(17.dp))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    CategoryChip(category, selectedCategory == category) { onCategoryChange(category) }
                }
            }
            Spacer(Modifier.height(22.dp))
            FeaturedEventCard(onClick = { onOpenEvent(sampleEvents.first()) })
            Spacer(Modifier.height(25.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Coming up", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("SAMPLE LISTINGS", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(11.dp))
            if (filtered.isEmpty()) {
                EmptyMessage("No events match that search.")
            } else {
                filtered.forEach { event ->
                    EventListItem(
                        event = event,
                        isSaved = savedIds.contains(event.id),
                        onClick = { onOpenEvent(event) },
                        onToggleSaved = { onToggleSaved(event) }
                    )
                    Spacer(Modifier.height(9.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
        }
    }
}

@Composable
private fun Modifier.verticalScrollCompat(): Modifier = this.verticalScroll(rememberScrollState())

@Composable
private fun SearchField(value: String, onValueChange: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(SoftIvory)
            .border(1.dp, Hairline, RoundedCornerShape(14.dp))
            .padding(horizontal = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("⌕", color = BrandRed, fontSize = 23.sp, fontWeight = FontWeight.Medium)
        Box(modifier = Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text("Search events or artists", color = Muted, fontSize = 14.sp)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = Ink, fontSize = 14.sp),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun CategoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) BrandRed else SoftIvory)
            .border(1.dp, if (selected) BrandRed else Hairline, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) BrandIvory else Ink,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
        )
    }
}

@Composable
private fun FeaturedEventCard(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)
            .clip(RoundedCornerShape(21.dp))
            .background(BrandRed)
            .clickable(onClick = onClick)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 1.2.dp.toPx()
            for (i in 0..4) {
                val inset = i * 17.dp.toPx()
                drawCircle(
                    color = BrandIvory.copy(alpha = 0.12f),
                    radius = 63.dp.toPx() + inset,
                    center = Offset(size.width * 0.88f, size.height * 0.53f),
                    style = Stroke(stroke)
                )
            }
            drawLine(
                color = BrandIvory.copy(alpha = 0.16f),
                start = Offset(size.width * 0.58f, 0f),
                end = Offset(size.width * 0.58f, size.height),
                strokeWidth = stroke
            )
        }
        Column(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 20.dp, top = 18.dp, bottom = 18.dp, end = 16.dp)
        ) {
            Text("SPOTLIGHT  ·  SAMPLE", color = BrandIvory.copy(alpha = 0.78f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(12.dp))
            Text("ADDIS\nLIVE SESSIONS", color = BrandIvory, fontSize = 25.sp, lineHeight = 27.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.7).sp)
            Spacer(Modifier.height(11.dp))
            Text("MUSIC  ·  ADDIS ABABA", color = BrandIvory.copy(alpha = 0.85f), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
        }
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .size(35.dp)
                .clip(CircleShape)
                .background(BrandIvory),
            contentAlignment = Alignment.Center
        ) {
            Text("↗", color = BrandRed, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EventListItem(
    event: DemoEvent,
    isSaved: Boolean,
    onClick: () -> Unit,
    onToggleSaved: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(15.dp))
            .background(SoftIvory)
            .border(1.dp, Hairline, RoundedCornerShape(15.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(62.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(BrandRed.copy(alpha = 0.11f)),
            contentAlignment = Alignment.Center
        ) {
            TicketMark(color = BrandRed, modifier = Modifier.size(35.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(event.date, color = BrandRed, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
            Spacer(Modifier.height(3.dp))
            Text(event.title, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text(event.venue, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            Text("From ETB ${event.price}", color = Ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(
            text = if (isSaved) "♥" else "♡",
            color = BrandRed,
            fontSize = 22.sp,
            modifier = Modifier
                .padding(start = 7.dp)
                .clip(CircleShape)
                .clickable(onClick = onToggleSaved)
                .padding(5.dp)
        )
    }
}

@Composable
private fun EventDetailScreen(
    event: DemoEvent,
    isSaved: Boolean,
    onBack: () -> Unit,
    onToggleSaved: () -> Unit
) {
    var ticketCount by remember(event.id) { mutableStateOf(1) }
    var showNotice by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandIvory)
            .padding(horizontal = 21.dp)
    ) {
        Spacer(Modifier.height(15.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("←", color = BrandRed, fontSize = 25.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 17.dp))
            Text("EVENT DETAILS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.weight(1f))
            Text(if (isSaved) "♥" else "♡", color = BrandRed, fontSize = 23.sp, modifier = Modifier.clickable(onClick = onToggleSaved))
        }
        Spacer(Modifier.height(19.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(BrandRed),
            contentAlignment = Alignment.Center
        ) {
            TicketMark(color = BrandIvory.copy(alpha = 0.9f), modifier = Modifier.size(86.dp))
        }
        Spacer(Modifier.height(21.dp))
        Text(event.category.uppercase() + "  ·  " + event.tag, color = BrandRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(6.dp))
        Text(event.title, color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp)
        Spacer(Modifier.height(8.dp))
        Text(event.date + "    ·    " + event.venue, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        Spacer(Modifier.height(26.dp))
        Text("Tickets", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(SoftIvory).border(1.dp, Hairline, RoundedCornerShape(15.dp)).padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Regular", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text("ETB ${event.price} / ticket", color = Muted, fontSize = 11.sp)
            }
            Text("−", color = BrandRed, fontSize = 23.sp, modifier = Modifier.clickable { if (ticketCount > 1) ticketCount-- }.padding(horizontal = 10.dp))
            Text(ticketCount.toString(), color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("+", color = BrandRed, fontSize = 23.sp, modifier = Modifier.clickable { if (ticketCount < 10) ticketCount++ }.padding(horizontal = 10.dp))
        }
        Spacer(Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text("TOTAL", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("ETB ${event.price * ticketCount}", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            RedActionButton(text = "Continue", onClick = { showNotice = true }, modifier = Modifier.width(150.dp))
        }
        Spacer(Modifier.height(16.dp))
    }
    if (showNotice) {
        AlertDialog(
            onDismissRequest = { showNotice = false },
            title = { Text("Preview only") },
            text = { Text("Ticket booking and payments will be connected in the next build.") },
            confirmButton = {
                Text("OK", color = BrandRed, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { showNotice = false }.padding(16.dp))
            },
            containerColor = SoftIvory,
            titleContentColor = Ink,
            textContentColor = Muted
        )
    }
}

@Composable
private fun TicketsScreen() {
    EmptyScreen(
        title = "Your tickets",
        message = "Tickets you book will appear here.",
        mark = "▤"
    )
}

@Composable
private fun SavedScreen(
    savedEvents: List<DemoEvent>,
    onOpenEvent: (DemoEvent) -> Unit,
    onToggleSaved: (DemoEvent) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(BrandIvory).padding(horizontal = 21.dp)) {
        Spacer(Modifier.height(22.dp))
        BrandStamp()
        Spacer(Modifier.height(22.dp))
        Text("Saved", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(15.dp))
        if (savedEvents.isEmpty()) {
            EmptyMessage("Events you save will appear here.")
        } else {
            savedEvents.forEach { event ->
                EventListItem(event, true, { onOpenEvent(event) }, { onToggleSaved(event) })
                Spacer(Modifier.height(9.dp))
            }
        }
    }
}

@Composable
private fun EmptyScreen(title: String, message: String, mark: String) {
    Column(
        modifier = Modifier.fillMaxSize().background(BrandIvory).padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(76.dp).clip(RoundedCornerShape(22.dp)).background(BrandRed.copy(alpha = 0.10f)),
            contentAlignment = Alignment.Center
        ) {
            Text(mark, color = BrandRed, fontSize = 33.sp)
        }
        Spacer(Modifier.height(19.dp))
        Text(title, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text(message, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun EmptyMessage(message: String) {
    Box(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SoftIvory).border(1.dp, Hairline, RoundedCornerShape(14.dp)).padding(19.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(message, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun AccountScreen(roleLabel: String, switchLabel: String, onSwitchRole: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().background(BrandIvory).padding(horizontal = 21.dp)) {
        Spacer(Modifier.height(22.dp))
        BrandStamp()
        Spacer(Modifier.height(24.dp))
        Text("Account", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(roleLabel, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(25.dp))
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(SoftIvory).border(1.dp, Hairline, RoundedCornerShape(15.dp)).clickable(onClick = onSwitchRole).padding(17.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(switchLabel, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("↗", color = BrandRed, fontSize = 20.sp)
        }
        Spacer(Modifier.height(17.dp))
        Text("Account sign-in will be added in the next build.", color = Muted, fontSize = 11.sp)
    }
}

private data class DraftEvent(val title: String, val venue: String, val date: String, val priceEtb: Int)

@Composable
private fun OrganizerApp(onSwitchRole: () -> Unit) {
    var selectedPage by remember { mutableStateOf("Overview") }
    var drafts by remember { mutableStateOf(listOf<DraftEvent>()) }
    var draftMessage by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().background(BrandIvory).systemBarsPadding()) {
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (selectedPage) {
                "Overview" -> OrganizerOverview(draftCount = drafts.size, onCreate = { selectedPage = "Create" })
                "Events" -> OrganizerEvents(drafts = drafts, onCreate = { selectedPage = "Create" })
                "Create" -> CreateEventScreen(
                    message = draftMessage,
                    onSave = { draft ->
                        drafts = drafts + draft
                        draftMessage = "Draft saved in this preview."
                    }
                )
                else -> AccountScreen("Event organiser", "Switch to ticket buyer", onSwitchRole)
            }
        }
        BottomBar(
            items = listOf("Overview", "Events", "Create", "Account"),
            selected = selectedPage,
            onSelect = { selectedPage = it }
        )
    }
}

@Composable
private fun OrganizerOverview(draftCount: Int, onCreate: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(BrandIvory).verticalScrollCompat().padding(horizontal = 21.dp)
    ) {
        Spacer(Modifier.height(22.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            BrandStamp()
            Text("ORGANISER", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        }
        Spacer(Modifier.height(27.dp))
        Text("Your events", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.7).sp)
        Spacer(Modifier.height(7.dp))
        Text("Create and manage your listings.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        Box(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(BrandRed).padding(20.dp)
        ) {
            Column {
                Text("EVENT DRAFTS", color = BrandIvory.copy(alpha = 0.75f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Spacer(Modifier.height(7.dp))
                Text(draftCount.toString(), color = BrandIvory, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                Text("In this preview session", color = BrandIvory.copy(alpha = 0.82f), fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(17.dp))
        RedActionButton(text = "+  Create an event", onClick = onCreate)
        Spacer(Modifier.height(24.dp))
        Text("Getting started", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Column(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(SoftIvory).border(1.dp, Hairline, RoundedCornerShape(15.dp)).padding(16.dp)) {
            Text("01   Create your event", color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Text("02   Add ticket types", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Text("03   Publish when ready", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun OrganizerEvents(drafts: List<DraftEvent>, onCreate: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().background(BrandIvory).padding(horizontal = 21.dp)) {
        Spacer(Modifier.height(22.dp))
        BrandStamp()
        Spacer(Modifier.height(23.dp))
        Text("Events", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(15.dp))
        if (drafts.isEmpty()) {
            EmptyMessage("Your event drafts will appear here.")
            Spacer(Modifier.height(16.dp))
            RedActionButton(text = "+  Create an event", onClick = onCreate)
        } else {
            drafts.forEach { draft ->
                Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SoftIvory).border(1.dp, Hairline, RoundedCornerShape(14.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(draft.title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(listOf(draft.date, draft.venue).filter { it.isNotBlank() }.joinToString(" · "), color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("DRAFT", color = BrandRed, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                    Text("ETB ${draft.priceEtb}", color = Ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(9.dp))
            }
            Spacer(Modifier.height(10.dp))
            RedActionButton(text = "+  Create another event", onClick = onCreate)
        }
    }
}

@Composable
private fun CreateEventScreen(message: String, onSave: (DraftEvent) -> Unit) {
    var title by remember { mutableStateOf("") }
    var venue by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(BrandIvory).verticalScrollCompat().padding(horizontal = 21.dp)) {
        Spacer(Modifier.height(22.dp))
        BrandStamp()
        Spacer(Modifier.height(23.dp))
        Text("Create event", color = Ink, fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text("Start with the essentials.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        FormField("Event name", title, { title = it })
        Spacer(Modifier.height(13.dp))
        FormField("Venue / location", venue, { venue = it })
        Spacer(Modifier.height(13.dp))
        FormField("Date", date, { date = it }, hint = "e.g. 20 Nov 2026")
        Spacer(Modifier.height(13.dp))
        FormField("Starting ticket price (ETB)", price, { input -> price = input.filter { it.isDigit() } }, hint = "e.g. 450")
        Spacer(Modifier.height(18.dp))
        RedActionButton(text = "Save draft", onClick = {
            if (title.isBlank()) error = "Add an event name first."
            else {
                onSave(DraftEvent(title.trim(), venue.trim(), date.trim(), price.toIntOrNull() ?: 0))
                error = ""
                title = ""
                venue = ""
                date = ""
                price = ""
            }
        })
        if (error.isNotBlank()) {
            Spacer(Modifier.height(9.dp))
            Text(error, color = BrandRed, fontSize = 11.sp)
        }
        if (message.isNotBlank()) {
            Spacer(Modifier.height(9.dp))
            Text(message, color = BrandRed, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(18.dp))
        Text("Drafts stay in this preview session. Publishing and ticket sales are not connected yet.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun FormField(label: String, value: String, onValueChange: (String) -> Unit, hint: String = "") {
    Column {
        Text(label, color = Ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = Modifier.fillMaxWidth().height(49.dp).clip(RoundedCornerShape(12.dp)).background(SoftIvory).border(1.dp, Hairline, RoundedCornerShape(12.dp)).padding(horizontal = 13.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (value.isEmpty()) Text(hint, color = Muted.copy(alpha = 0.75f), fontSize = 12.sp)
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = Ink, fontSize = 13.sp),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun RedActionButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(BrandRed)
            .clickable(onClick = onClick)
            .padding(horizontal = 17.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = BrandIvory, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BottomBar(items: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(BrandIvory)
            .border(BorderStroke(0.7.dp, Hairline))
            .padding(horizontal = 5.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { item ->
            Column(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { onSelect(item) }.padding(vertical = 7.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(modifier = Modifier.width(22.dp).height(3.dp).clip(RoundedCornerShape(50)).background(if (item == selected) BrandRed else Color.Transparent))
                Text(
                    item,
                    color = if (item == selected) BrandRed else Muted,
                    fontSize = 9.sp,
                    fontWeight = if (item == selected) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1
                )
            }
        }
    }
}
