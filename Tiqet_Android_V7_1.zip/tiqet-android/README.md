# Tiqet Android — V7.2 provider-neutral marketplace payment core (0.4.2)

Tiqet is a native Android event-discovery and ticketing app for Ethiopia. This build keeps the audited Chapa checkout path and adds a provider-neutral payment registry, organiser settlement ledger/history, reconciliation accounting and a generic checkout API. The current executable pay-in adapter remains Chapa.

## Implemented in this source package

### Buyer payments

- Hosted Chapa v2 checkout is initialized only by a Supabase Edge Function.
- The server reads the provider's live payment-method list and only accepts methods enabled for this merchant, ETB, and Ethiopia.
- Chapa's hosted checkout presents the methods enabled on the merchant account. Current Chapa documentation lists pay-in options including Telebirr, CBE Birr, M-Pesa, CBE bank transfer, Awash/AwashBirr, Coopay-Ebirr, Amole, Enat Bank, Amhara Bank, COOP, and cards. The provider may enable only a subset for a particular merchant account; the app does not promise all of them are active.
- The buyer sees the ticket subtotal, the 5% Tiqet service fee, and the estimated total before opening checkout. The server recomputes and stores the authoritative amount.
- Payment is not considered successful because the browser says “success”. The signed webhook is authenticated and the payment is independently verified against the exact merchant reference, amount, and ETB currency before tickets are issued.

### Marketplace settlement

- Default buyer service fee: 5% of ticket subtotal, capped at ETB 100 per order, with no minimum fee. Free tickets have no service fee.
- Default organiser commission: 5% of ticket subtotal.
- The order displays the Tiqet service fee separately. The organiser agreement must disclose the organiser commission before an event can go on sale.
- Chapa split payments route the organiser's ticket subtotal minus Tiqet's 5% commission to the organiser's connected Chapa subaccount. Tiqet's primary merchant balance receives the buyer service fee plus organiser commission, before payment-provider fees, taxes, refunds, and operating costs.
- The exact organiser split amount is stored with the payment at checkout and reused for the revenue ledger; later pricing changes do not rewrite an existing order's split.
- Paid event checkout is blocked until the verified organiser connects a supported settlement destination. The app stores only the provider subaccount reference, destination slug, and last four account digits; the full account number is sent to Chapa over HTTPS and is not saved in Tiqet's tables.
- **Marketplace approval is a hard launch dependency.** Chapa's terms restrict payment-facilitator/sub-merchant activity unless it is registered/licensed or operating under a pre-approved broad-based marketplace/technology partner program. Obtain written Chapa approval for Tiqet's marketplace, organiser subaccounts, split percentages, refunds and payout model before accepting public payments. Do not assume API access alone authorises this business model.

### Tiqet owner revenue and cash-out

- An owner-only revenue panel appears in the organiser workspace when `TIQET_OWNER_USER_ID` is configured with the founder's Supabase Auth user UUID.
- It displays the revenue ledger, successful withdrawals, payout fees, and amount remaining before external costs. Totals are aggregated in PostgreSQL, not limited to a REST page size.
- The owner can submit a withdrawal to an active bank or mobile-money destination returned by Chapa's live Ethiopia payout-bank API.
- A withdrawal checks Chapa's latest available ETB balance and Tiqet's internal ledger, reserves funds before the provider request, then verifies the payout and awaits the signed payout webhook for later status changes. A created or pending request is **not** displayed as completed until Chapa verification reports success.
- Payout account numbers are not persisted in Tiqet's database. Only account holder, destination slug, and last four digits are stored for audit.

## Revenue strategy

The built-in launch model is a 5% buyer service fee plus a 5% organiser commission: a 10% combined platform take, with a hard 15% combined ceiling in the financial-settings table. For a 500 ETB ticket order, the buyer sees 25 ETB added as a clearly labelled service fee and pays 525 ETB total; the organiser receives 475 ETB before any separately agreed provider-side deductions; Tiqet receives 50 ETB gross before payment-processing fees, payout fees, taxes, refunds, disputes, and operating costs. Free tickets have no fee. The buyer fee is capped at ETB 100 per order, with no minimum. The 15% figure is a future configurable ceiling, not the launch rate. Any rate change must be disclosed before checkout and in organiser terms.

Additional revenue streams to launch only when the matching feature exists:

1. Clearly labelled sponsored/boosted event placements, sold as fixed time packages.
2. Optional organiser subscription tiers for advanced analytics, team seats, campaign tools, and priority support.
3. Event promotion services such as campaign creatives, email/SMS reminders where consent and provider compliance permit, and ticket-sales campaigns.
4. Venue, festival, brand, and media partnerships, with sponsored content clearly labelled.
5. Large-organiser/enterprise tools, such as multi-event reporting, staff access controls, exports, and dedicated support.

Do not sell attendee personal data. Do not hide checkout charges. Do not charge for a promotional placement unless it is actually delivered and labelled as sponsored.

## Payment method coverage: what this means

**Via Chapa hosted checkout (subject to merchant enablement):** Telebirr, CBE Birr, M-Pesa, CBE bank transfer, and the other methods shown in Chapa's current payment-methods API for the merchant. The app asks Chapa's live API for the current list; it does not hard-code or promise unsupported methods.

**Bank of Abyssinia:** Chapa's consolidated hosted-checkout method table does not currently list BOA Card as a pay-in method (it lists BOA Card under payout). Chapa's separate Direct Charge documentation does mention a `boa_ussd` method, but that is a distinct, method-specific authorization flow and is not the same as hosted BOA card checkout. V7.1 does **not** implement that Direct Charge adapter. BOA also publishes a separate merchant e-commerce gateway that requires merchant onboarding and bank-provided API documentation/credentials. Tiqet can add BOA only after Chapa confirms `boa_ussd` eligibility for this merchant or BOA approves a direct gateway integration and provides sandbox/production specifications.

**Other providers:** Telebirr has an official developer portal and direct integration process. ArifPay, AddisPay, SantimPay, Yagout Pay and other licensed payment-system operators can be evaluated as additional provider adapters after merchant onboarding, technical documentation, pricing, settlement, refund, and support terms are verified. They are not marked live in this build.

## Required backend setup — do not skip

This package does not activate private payment accounts or complete provider approvals. Apply migrations 003, 004 and 005 in sequence after the already-applied migrations 001 and 002. Do not rerun migrations 001 or 002. Deploy the Edge Functions after migration 005.

### A. Apply migrations 003, 004 and 005

1. Open the Tiqet Supabase project: `https://supabase.com/dashboard/project/ebrrdmxyoioefoprtict`.
2. Open **SQL Editor → New query**.
3. Run `003_payment_review_and_refund_safety.sql` once. It adds late-payment inventory-release protection, durable refund alerts, and a check-in safety guard.
4. After migration 003 succeeds, run `004_provider_balance_aware_payout_reserve.sql` once. It checks Chapa's current available ETB balance and Tiqet's own in-flight payout reservations before a platform withdrawal can be reserved.
5. Run `005_provider_agnostic_payment_core.sql` after migration 004. It adds the provider registry, provider-linked organiser accounts, payment attempt events, organiser settlement ledger, payout requests and refund/chargeback reconciliation adjustments.
6. Do not rerun migrations 001 or 002. Do not delete existing production data.

### B. Set Supabase Edge Function secrets

In **Project Settings → Edge Functions → Secrets** (or the Edge Function Secrets page), add:

- `CHAPA_PRIVATE_KEY` — your Chapa test private key first; use live key only after a passing end-to-end test and merchant approval.
- `CHAPA_WEBHOOK_SECRET` — a long random secret that exactly matches the Signature-authentication secret configured in Chapa.
- `TIQET_OWNER_USER_ID` — the founder's UUID from **Authentication → Users**. It is not the email address.
- `CHAPA_MODE` — must explicitly be `test` or `live`. Keep it on `test` for sandbox work.
- `TIQET_LIVE_MARKETPLACE_APPROVED` — leave unset/`false`. Set to `true` only after written Chapa marketplace/sub-merchant approval, business KYC and any required regulatory authorisation.
- `TIQET_LIVE_PAYOUTS_ENABLED` — leave unset/`false`. Set to `true` only after the live payout flow and marketplace approval are confirmed.

Supabase automatically provides its project URL, anon key, and service-role key to Edge Functions. Never add the Chapa private key or Supabase service-role key to Android source, GitHub repository variables, or the APK.

### C. Deploy the Edge Functions from GitHub Actions

1. In Supabase, open **Account → Access Tokens** and create a personal access token. Treat it as a password.
2. In the Tiqet GitHub repository, open **Settings → Secrets and variables → Actions → New repository secret**.
3. Add a secret named exactly `SUPABASE_ACCESS_TOKEN` and paste the Supabase access token. Do not use a publishable key here.
4. Upload `Tiqet_Android_V7_1.zip` to the repository root.
5. Open **Actions → Deploy Tiqet V7.2 Edge Functions → Run workflow**. The V7.2 workflow deploys the Chapa functions plus `create-payment-intent` and `payment-provider-catalog`. The deployment workflow extracts the V7.2 source and deploys the functions using the official Supabase CLI action.

### D. Configure Chapa

1. Complete merchant onboarding with the required business documents, and ask Chapa for written approval of Tiqet as a ticketing marketplace with organiser sub-merchants and split settlement. Its terms identify payment-facilitator/sub-merchant models as requiring registration/licensing or a pre-approved program. Confirm who bears processing fees, payout fees, refunds, chargebacks and reversals in the signed agreement.
2. Enable the payment methods and payout/split-settlement features you intend to use.
3. Configure one signed webhook endpoint:

   `https://ebrrdmxyoioefoprtict.supabase.co/functions/v1/chapa-webhook`

4. Choose **Signature** authentication and enter the same secret stored as `CHAPA_WEBHOOK_SECRET` in Supabase.
5. Enable payment and payout events. The webhook code verifies the raw-body HMAC before reading the payload, then verifies each payment/payout against Chapa. Signed refund notices are stored and move orders into review; they are not automatically reconciled to ticket or ledger adjustments.
6. Use test mode and Chapa's documented test accounts first. A production payment must not be attempted until payment, split settlement, failed payment, duplicate webhook, payout success, payout failure, and payout reversal have all been tested.

### E. Build the Android APK

1. Upload `Tiqet_Android_V7_1.zip` to the repository root.
2. Upload `build-tiqet-v7-1.yml` to `.github/workflows/build-tiqet-v7-1.yml`.
3. Confirm repository **Variables** still contain `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
4. Open **Actions → Build Tiqet Android V7.2 → Run workflow**.
5. Download the `tiqet-v7-2-debug-apk` artifact after the workflow reports success. A successful build proves compilation only; install and test on a real Android phone.

## Current project configuration

- Supabase project: `ebrrdmxyoioefoprtict`
- App package: `et.events.mobile`
- Android min SDK: 24 (Android 7.0)
- Target SDK: 36; compile SDK: 37
- JDK 17; Gradle 9.3.1; Android Gradle Plugin 9.1.1
- App version: 0.4.2, versionCode 8
- Native email callback: `tiqet://auth/callback`

## Release limitations — do not treat V7.2 as production-ready

This source package implements the checkout/split/cash-out integration path, but it has **not** been deployed to your private Supabase project or tested against your Chapa merchant account from this chat. Real provider activation requires your own merchant approval, API keys, enabled payment methods, and account/settlement verification.

Still required before public sale: written Chapa approval for the marketplace/sub-merchant model (and confirmation of any NBE licensing requirements with qualified Ethiopian counsel), deployment of migration 005 and the updated Edge Functions, end-to-end sandbox tests, direct Bank of Abyssinia pay-in integration if approved, additional provider adapters with official specifications, outbound refund initiation and provider verification, an operator interface for reconciliation adjustments, partial-refund ticket allocation rules, chargeback and split-reversal operational procedures, admin moderation UI, event-image upload/display, staff assignment and offline check-in sync, Amharic localisation, legal/privacy/refund documents, monitoring and reconciliation, and a signed release APK/AAB. Cash-out ledger figures are gross before processing fees, taxes, refunds, disputes, and operating expenses; they are not accounting profit. The withdrawal endpoint validates Chapa's current payout destinations, checks the provider's available ETB balance as well as Tiqet's internal ledger, and waits for Chapa verification. Chapa may still reject or reverse a bank/mobile-wallet transfer, and payout fees may affect the final withdrawable amount.

## Brand

- Name: **Tiqet**
- Red: `#B82035`
- Warm ivory: `#F7F1E7`
- Main text: `#2B2020`
- Existing launcher mark retained.


## V7.1.1 refund and payout safety behavior

Signed Chapa refund notifications are now stored as refund alerts and move the associated order into `payment_review`. The check-in RPC refuses to admit tickets attached to an order in that state. This is deliberately conservative: the webhook payload identifies the payment but not a unique refund reference. A refund must be reconciled against Chapa's refund reference/verification and an operator must determine the exact ticket and revenue adjustments. V7.1 originally did not automatically mark tickets refunded or alter the revenue ledger. V7.2 adds an audited, service-role-only manual reconciliation path for provider-confirmed full/partial refunds, chargebacks and split reversals. It still does not initiate provider refunds or provide an admin reconciliation UI. Public sales remain blocked until the complete operational process is tested and approved.


Migration 004 is an additional backend-only safeguard. It checks Chapa's live `available_balance.ETB` and reserves against Tiqet's own in-flight payouts under a database advisory lock before any payout request is sent. The comparison is conservative when Chapa has already removed a pending payout from its available balance. No cash-out should be attempted in test mode except against test credentials.


Migration 004 is a backend-only cash-out safeguard. It checks Chapa's live `available_balance.ETB` and reserves against Tiqet's own in-flight payouts under a database advisory lock before any payout request is sent. The comparison is conservative if Chapa has already removed a pending transfer from the provider's available balance.


## V7.2 provider-neutral payment core

- Android now calls `create-payment-intent` with a provider slug. The existing `createChapaCheckout` API remains as a backwards-compatible wrapper.
- `payment-provider-catalog` returns provider activation state and, for Chapa, methods enabled for the actual merchant at request time. It does not promise methods which Chapa has not enabled.
- Migration 005 introduces separate provider account references per organisation. Existing Chapa subaccounts are backfilled and new connections are written to the generic table. Full payout account numbers are not retained.
- Organiser net earnings are recorded in an append-only ETB ledger. Owners can retrieve a verified organisation's summary and transaction history. Payout requests are queued and require a separate, authorised provider/operator workflow; submitting a request does not move money.
- Provider-confirmed refunds/chargebacks/split reversals are reconciled through `payment_reconciliation_adjustments` and the service-role-only `reconcile_payment_adjustment` RPC. The operator must record exact platform and organiser adjustment shares. Partial refunds leave the order in review; full refunds revoke issued tickets.
- ArifPay, FenanPay, SantimPay and YagoutPay are registered but disabled. Their API adapters are not fabricated. They must not be enabled until Tiqet has each provider's current official API contract, merchant approval, sandbox credentials, webhook signing rules, and written split/payout/refund terms.

### V7.2 release sequence

1. Apply migration 005 after 003 and 004.
2. Deploy all Edge Functions using the new V7.2 deploy workflow.
3. Keep `CHAPA_MODE=test` and both live-enable flags false.
4. Run sandbox tests for checkout, duplicate/malformed webhook, amount mismatch, payment failure, full/partial refund reconciliation, payout reservation, organiser history and owner revenue.
5. Only after written approval and testing, configure live credentials and separately enable live marketplace checkout and platform payouts.

The migration and code create the software foundations; they do not themselves obtain a payment licence, provider approval, clear funds or activate Telebirr/CBE/M-PESA/Bank of Abyssinia direct rails.
