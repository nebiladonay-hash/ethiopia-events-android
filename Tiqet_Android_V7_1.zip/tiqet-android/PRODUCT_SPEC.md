# Tiqet — product and security specification (V7)

## Product

One native Android application for buyers and organisers. A signed-in user can switch buyer/organiser experiences with one account. Organisations must be verified before they can publish paid events. Staff check-in access remains event-scoped.

## Brand and platform

- Name: Tiqet
- Red `#B82035`; warm ivory `#F7F1E7`; ink `#2B2020`
- Native Android min API 24, target API 36, compile API 37.
- ETB pricing; event times use Africa/Addis_Ababa.

## Existing buyer and organiser flows

Buyer: Supabase account sign-up/sign-in, approved event discovery, event detail, server-side ticket reservation, Chapa hosted checkout, QR ticket retrieval.

Organiser: organisation verification application; verified-organiser event submission; payout destination setup through Chapa subaccounts; paid checkout requires a connected settlement destination; QR check-in rejects duplicate entry.

## Monetisation and settlement

- Buyer service fee default is 5% of order ticket subtotal, capped at ETB 100 per order, with no minimum. Free orders pay no buyer fee.
- Organiser commission default is 5% of ticket subtotal. The combined default Tiqet take is 10%, and the financial-settings table enforces a 15% combined ceiling.
- Both buyer fee and organiser commission are disclosed; buyer subtotal/service fee/total are visible before external checkout.
- Chapa hosted checkout uses a stored flat split amount for the organiser's ticket subtotal less the 5% organiser commission. Tiqet's primary merchant account retains the buyer fee plus organiser commission before provider costs.
- Exact split amount is stored in payment metadata and used for revenue ledger accounting.
- Platform owner cash-outs are restricted to the configured Supabase Auth user UUID and active Chapa payout destinations. Withdrawals are reserved atomically, submitted idempotently, verified against amount/currency/reference, and remain pending until provider confirmation.
- Financial ledger totals are gross before provider fees, payout fees, taxes, refunds, disputes and operating costs. A ledger balance is not net profit or necessarily the current cleared provider balance.

## Payment-method policy

Chapa's live ETB/Ethiopia payment-method API determines the actual methods offered at checkout. Current published Chapa pay-in options include Telebirr, CBE Birr, M-Pesa, CBE Bank Transfer and other options. This does not guarantee every method is enabled for a particular Tiqet merchant account.

Chapa's consolidated hosted-checkout methods table currently lists BOA Card as a payout method, not a hosted pay-in method. A separate Chapa Direct Charge reference mentions `boa_ussd`; this is not the hosted-checkout integration and is not implemented in V7. Direct BOA e-commerce pay-in remains gated on Chapa method eligibility or a separate BOA merchant agreement, API specifications, credentials and sandbox test. ArifPay, AddisPay, SantimPay, Yagout Pay and a separate direct Telebirr integration are possible future adapters, not live integrations in this build.

## Transaction and security invariants

1. Database owns ticket inventory, price, fee and order total.
2. `create_order_hold` locks the ticket type and reserves stock for ten minutes.
3. Chapa private keys and Supabase service-role credentials exist only in Supabase Edge Function secrets.
4. Payment and payout webhooks verify the raw-body HMAC-SHA256 signature in constant time before parsing.
5. Payment success is independently verified with Chapa for exact merchant reference, amount and ETB currency before tickets are issued.
6. The exact organiser split amount sent at checkout is recorded with the payment and reused by the revenue ledger.
7. The owner-only withdrawal RPC uses a transaction-scoped advisory lock to prevent concurrent over-withdrawal.
8. Payout creation does not establish completion; payout verification and signed webhooks govern the final state.
9. QR ticket tokens are server-generated and check-in uses an atomic single-use state transition.
10. No screenshot, receipt image, or client-side “success” state can issue a ticket.

## Release gates

V7 source is not production-certified. Required before public sales: deploy migration 002 and functions, Chapa test-mode end-to-end cases, payment and split reconciliation, payout success/failure/reversal tests, refund/chargeback and split-reversal accounting, direct BOA integration if approved, device testing across supported Android versions, admin moderation, event media, staff assignment/offline scanner sync, Amharic localisation, privacy/terms/refund policies, monitoring and production signing.
