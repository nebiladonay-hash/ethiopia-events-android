# Tiqet V7 — marketplace monetisation and owner cash-out

- Increased Android app version to 0.4.0 (versionCode 6).
- Added database migration 002 for transparent buyer service fees, organiser commission snapshots, revenue ledger, payout ledger, owner summary RPC and locked cash-out reservations.
- Buyer checkout now visibly breaks down ticket subtotal, 5% Tiqet service fee (capped at ETB 100), and total.
- Added Chapa dynamic ETB payment-method lookup and live Ethiopia payout-bank lookup.
- Added Chapa organiser subaccount creation and direct split settlement of organiser ticket proceeds.
- Added owner-only platform revenue summary and Chapa payout/cash-out flow with post-creation verification and signed webhook updates.
- Launch pricing is 5% buyer service fee + 5% organiser commission (10% combined), with the buyer fee capped at ETB 100 and a 15% combined configurable ceiling.
- Added service-fee/organiser-commission revenue accounting from the persisted per-order split snapshot.
- Added deployment and setup instructions.

Not claimed as complete: the separate Chapa `boa_ussd` Direct Charge adapter and direct BOA buyer payment, direct ArifPay/AddisPay/SantimPay/Yagout Pay adapters, refund/chargeback and split-reversal workflow, admin moderation, event images, staff/offline scanner, Amharic localisation, and real-account end-to-end validation.

## V7.2 provider-neutral payment core

See `V7_2_PAYMENT_CORE_CHANGELOG.md` for provider registry, generic checkout routing, organiser settlement history, adjustment accounting, live-payment safety locks and integration limits.
