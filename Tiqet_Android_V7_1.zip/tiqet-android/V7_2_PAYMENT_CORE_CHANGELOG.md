# Tiqet V7.2 — provider-neutral payment core

## Built in this revision

- Added a provider registry with explicit adapter state, checkout eligibility, marketplace-split capability and organiser-payout capability.
- Added provider-neutral payment/account records so one organisation can connect a settlement account per provider without storing full bank or wallet account numbers.
- Added a generic `create-payment-intent` endpoint. Chapa routes to the existing audited checkout implementation; ArifPay, FenanPay, SantimPay and YagoutPay fail closed until their merchant contracts, current API specifications and sandbox credentials are installed.
- Added a generic payment-adapter TypeScript contract and a live merchant-specific payment-provider catalogue endpoint.
- Added payment-attempt audit events and a provider-neutral settlement-split snapshot while keeping the existing Chapa webhook verification path.
- Added an immutable organiser settlement ledger, ownership-checked balance/history RPCs, idempotent payout requests and service-role-only payout resolution. A request is not a transfer.
- Added controlled payment reconciliation adjustments for provider-confirmed refunds, chargebacks and split reversals. Partial refunds keep the order in review; a fully reconciled refund marks the order and issued tickets refunded.
- Added platform adjustment accounting and changed the platform withdrawal ceiling to use net revenue after reconciled adjustments.
- Added live-mode safety locks. Live checkout requires `TIQET_LIVE_MARKETPLACE_APPROVED=true`; live platform payouts separately require `TIQET_LIVE_PAYOUTS_ENABLED=true`.
- Added organiser settlement ledger/history readouts to the native organiser workspace and updated the payment API to use the generic checkout router.
- Android version updated to 0.4.2 / versionCode 8.

## Validation scope

Source-level checks are required before packaging. The Android Gradle build must run in GitHub Actions. Migration 005 must be applied manually after migrations 001–004. Supabase functions must be deployed after the migration. No live payment, refund or payout is claimed to have been performed by this source revision.

## Explicitly not activated

ArifPay, FenanPay, SantimPay and YagoutPay are registered as disabled provider slots, not falsely represented as completed integrations. Their exact API contracts, merchant approval, settlement/split semantics, sandbox credentials and refund/payout webhooks must be verified before adapters can be enabled. The system must not hold or pay out third-party funds outside the approved licensed-provider arrangement.
