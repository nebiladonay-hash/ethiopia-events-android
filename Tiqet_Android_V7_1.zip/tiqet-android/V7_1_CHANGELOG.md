# Tiqet V7.1.1 — payment safety correction

- Fixed late verified-payment reconciliation so inventory reservations are released exactly once when a pending hold is moved into payment review.
- Added durable, idempotent storage for signed Chapa refund notices. Refund notifications place the order into payment review and prevent subsequent event check-in until reconciliation.
- Did not automatically mark tickets refunded or reverse revenue: Chapa V2 requires refund-reference reconciliation, and the current webhook payload does not contain an individual refund reference.
- Hardened the check-in RPC so only tickets belonging to paid orders can be checked in.
- Android app version bumped to 0.4.1 / versionCode 7.
- Corrected GitHub Actions Android SDK installation to use the SDK package path `platforms;android-37`.
- Added a provider-balance-aware payout reservation: the Edge Function checks Chapa `available_balance.ETB`, and the database atomically accounts for Tiqet's own in-flight withdrawals before reserving another.
- Webhook persistence failures now return a retryable error rather than acknowledging updates that did not persist.

## Validation limits

TypeScript parser-level transpilation and workflow YAML parsing will be checked before delivery. SQL is source-reviewed only. A full Android Gradle build, SQL execution against Tiqet's live Supabase project, Supabase Edge Function deployment, and Chapa sandbox transaction have not been run from this environment.
