-- Tiqet V7.1.1 payout safety correction.
-- Apply AFTER 003_payment_review_and_refund_safety.sql.
-- This does not move money. It prevents a payout request from exceeding the
-- live Chapa ETB available balance after Tiqet's own in-flight payout reserves.

begin;

create or replace function public.reserve_tiqet_platform_payout(
  p_amount_minor bigint,
  p_bank_slug text,
  p_bank_name text,
  p_account_name text,
  p_account_number text,
  p_chapa_available_balance_minor bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_gross numeric(14,2);
  v_reserved numeric(14,2);
  v_provider_reserved bigint;
  v_requested numeric(14,2);
  v_reference text;
  v_id uuid;
begin
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext('tiqet_platform_payout_reserve'));
  if p_amount_minor is null or p_amount_minor < 100 then
    raise exception 'Minimum withdrawal is ETB 1.00';
  end if;
  if p_chapa_available_balance_minor is null or p_chapa_available_balance_minor < 0 then
    raise exception 'Could not verify the current Chapa available balance';
  end if;
  if p_bank_slug is null or length(trim(p_bank_slug)) = 0 then
    raise exception 'Choose a valid destination bank or wallet';
  end if;
  if p_account_name is null or length(trim(p_account_name)) < 2 then
    raise exception 'Account holder name is required';
  end if;
  if p_account_number is null or length(regexp_replace(p_account_number, '[^0-9]', '', 'g')) < 6 then
    raise exception 'Enter a valid destination account number';
  end if;

  v_requested := round(p_amount_minor::numeric / 100, 2);
  select coalesce(sum(platform_gross_revenue_etb),0)
    into v_gross from public.platform_revenue_ledger;
  select coalesce(sum(amount_minor::numeric / 100),0)
    into v_reserved
    from public.platform_payouts
    where status in ('reserved','pending','succeeded','blocked','auth_needed','otp_needed');
  if v_requested > greatest(0, v_gross - v_reserved) then
    raise exception 'Withdrawal exceeds Tiqet revenue balance available in the ledger';
  end if;

  -- Chapa's balance is authoritative for available funds. Keep local in-flight
  -- transfers reserved too. This is conservative if Chapa has already deducted
  -- a pending payout from available_balance; it favours safety over liquidity.
  select coalesce(sum(amount_minor),0)::bigint
    into v_provider_reserved
    from public.platform_payouts
    where status in ('reserved','pending','blocked','auth_needed','otp_needed');
  if p_amount_minor + v_provider_reserved > p_chapa_available_balance_minor then
    raise exception 'Withdrawal exceeds Chapa available balance after in-flight payout reservations';
  end if;

  v_reference := 'TQP' || upper(substr(encode(extensions.gen_random_bytes(10),'hex'),1,17));
  insert into public.platform_payouts(
    amount_minor, bank_slug, bank_name, account_name, account_last4,
    merchant_reference, status
  ) values (
    p_amount_minor, trim(p_bank_slug), coalesce(nullif(trim(p_bank_name),''),trim(p_bank_slug)),
    trim(p_account_name), right(regexp_replace(p_account_number, '[^0-9]', '', 'g'),4),
    v_reference, 'reserved'
  ) returning id into v_id;

  return jsonb_build_object('id',v_id,'merchant_reference',v_reference,
                            'amount_minor',p_amount_minor,'amount_etb',v_requested);
end;
$$;

revoke all on function public.reserve_tiqet_platform_payout(bigint,text,text,text,text,bigint)
  from public, anon, authenticated;
grant execute on function public.reserve_tiqet_platform_payout(bigint,text,text,text,text,bigint)
  to service_role;

-- The former five-argument overload must not remain callable as an alternate
-- path that bypasses the provider-balance check.
revoke all on function public.reserve_tiqet_platform_payout(bigint,text,text,text,text)
  from public, anon, authenticated, service_role;
drop function if exists public.reserve_tiqet_platform_payout(bigint,text,text,text,text);

commit;
