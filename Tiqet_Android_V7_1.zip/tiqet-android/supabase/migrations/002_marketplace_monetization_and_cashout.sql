-- Tiqet marketplace monetization, organiser settlement, and platform cash-out.
-- Apply AFTER 001_tiqet_core.sql. All customer-facing amounts are ETB.
-- Default pricing: 5% buyer service fee (ETB 100 maximum, no minimum)
-- plus 5% organiser commission. Combined default platform take is 10%;
-- the two rates may never exceed 15% combined.

begin;

alter table public.organisations
  add column if not exists chapa_subaccount_reference text unique,
  add column if not exists payout_method text,
  add column if not exists payout_account_last4 text,
  add column if not exists payout_setup_at timestamptz;

create table if not exists public.platform_financial_settings (
  singleton boolean primary key default true check (singleton),
  buyer_fee_rate numeric(6,5) not null default 0.05000 check (buyer_fee_rate between 0 and 0.15),
  buyer_fee_min_etb numeric(12,2) not null default 0.00 check (buyer_fee_min_etb >= 0),
  buyer_fee_max_etb numeric(12,2) not null default 100.00 check (buyer_fee_max_etb >= buyer_fee_min_etb),
  organiser_commission_rate numeric(6,5) not null default 0.05000 check (organiser_commission_rate between 0 and 0.15),
  check (buyer_fee_rate + organiser_commission_rate <= 0.15),
  updated_at timestamptz not null default now()
);
insert into public.platform_financial_settings(singleton)
values (true) on conflict (singleton) do nothing;

create table if not exists public.platform_revenue_ledger (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete restrict,
  organisation_id uuid references public.organisations(id) on delete restrict,
  currency text not null default 'ETB' check (currency = 'ETB'),
  ticket_subtotal_etb numeric(12,2) not null check (ticket_subtotal_etb >= 0),
  buyer_service_fee_etb numeric(12,2) not null check (buyer_service_fee_etb >= 0),
  organiser_commission_etb numeric(12,2) not null check (organiser_commission_etb >= 0),
  platform_gross_revenue_etb numeric(12,2) not null check (platform_gross_revenue_etb >= 0),
  organiser_net_settlement_etb numeric(12,2) not null check (organiser_net_settlement_etb >= 0),
  created_at timestamptz not null default now()
);
create index if not exists platform_revenue_ledger_created_idx
  on public.platform_revenue_ledger(created_at desc);

create table if not exists public.platform_payouts (
  id uuid primary key default gen_random_uuid(),
  amount_minor bigint not null check (amount_minor >= 100),
  currency text not null default 'ETB' check (currency = 'ETB'),
  bank_slug text not null,
  bank_name text not null,
  account_name text not null,
  account_last4 text not null,
  merchant_reference text not null unique,
  provider_reference text,
  provider_service_fee_minor bigint not null default 0 check (provider_service_fee_minor >= 0),
  status text not null default 'reserved'
    check (status in ('reserved','pending','succeeded','failed','reversed','blocked','auth_needed','otp_needed','otp_failed')),
  provider_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists platform_payouts_status_idx on public.platform_payouts(status, created_at desc);

alter table public.platform_financial_settings enable row level security;
alter table public.platform_revenue_ledger enable row level security;
alter table public.platform_payouts enable row level security;
-- These tables are private accounting records. No anon/authenticated table policies are created.
revoke all on public.platform_financial_settings, public.platform_revenue_ledger, public.platform_payouts from anon, authenticated;
grant select, insert, update, delete on public.platform_financial_settings, public.platform_revenue_ledger, public.platform_payouts to service_role;

-- Replace the order-hold RPC so the buyer fee is fixed in the order before checkout.
create or replace function public.create_order_hold(p_ticket_type_id uuid, p_quantity integer)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_type public.ticket_types%rowtype;
  v_event public.events%rowtype;
  v_order_id uuid;
  v_reference text;
  v_subtotal numeric(12,2);
  v_fee numeric(12,2);
  v_total numeric(12,2);
  v_fee_rate numeric(6,5);
  v_fee_min numeric(12,2);
  v_fee_max numeric(12,2);
  v_item_id uuid;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_quantity is null or p_quantity < 1 or p_quantity > 10 then raise exception 'Quantity must be between 1 and 10'; end if;

  for v_order_id in
    select o.id from public.orders o
    join public.order_items oi on oi.order_id = o.id
    where oi.ticket_type_id = p_ticket_type_id
      and o.status = 'payment_pending'
      and o.hold_expires_at <= now()
    for update of o
  loop
    update public.orders set status = 'expired', updated_at = now()
      where id = v_order_id and status = 'payment_pending';
    update public.ticket_types t
      set quantity_reserved = greatest(0, t.quantity_reserved - coalesce((
        select sum(oi.quantity) from public.order_items oi
        where oi.order_id = v_order_id and oi.ticket_type_id = t.id
      ),0)), updated_at = now()
      where t.id = p_ticket_type_id;
  end loop;

  select * into v_type from public.ticket_types where id = p_ticket_type_id for update;
  if not found then raise exception 'Ticket type not found'; end if;
  select * into v_event from public.events where id = v_type.event_id;
  if v_event.status <> 'published' or v_event.approval_status <> 'approved' then raise exception 'Event is not available for sale'; end if;
  if v_type.sales_start is not null and v_type.sales_start > now() then raise exception 'Ticket sales have not started'; end if;
  if v_type.sales_end is not null and v_type.sales_end <= now() then raise exception 'Ticket sales have ended'; end if;
  if p_quantity > v_type.per_order_limit then raise exception 'Quantity exceeds the per-order limit'; end if;
  if (v_type.quantity_total - v_type.quantity_reserved - v_type.quantity_sold) < p_quantity then raise exception 'Not enough tickets are available'; end if;

  v_subtotal := round(v_type.price_etb * p_quantity, 2);
  select buyer_fee_rate, buyer_fee_min_etb, buyer_fee_max_etb
    into v_fee_rate, v_fee_min, v_fee_max
    from public.platform_financial_settings where singleton = true;
  v_fee := case when v_subtotal = 0 then 0 else least(v_fee_max, greatest(v_fee_min, round(v_subtotal * v_fee_rate, 2))) end;
  v_total := v_subtotal + v_fee;
  v_order_id := gen_random_uuid();
  v_reference := 'TQ' || upper(substr(encode(extensions.gen_random_bytes(12),'hex'),1,18));

  insert into public.orders(id, buyer_id, status, subtotal_etb, fees_etb, total_etb, merchant_reference, hold_expires_at)
  values (v_order_id, v_user, 'payment_pending', v_subtotal, v_fee, v_total, v_reference, now() + interval '10 minutes');
  insert into public.order_items(order_id, ticket_type_id, event_id, ticket_name_snapshot, unit_price_etb, quantity, line_total_etb)
  values (v_order_id, v_type.id, v_event.id, v_type.name, v_type.price_etb, p_quantity, v_subtotal)
  returning id into v_item_id;
  update public.ticket_types set quantity_reserved = quantity_reserved + p_quantity, updated_at = now() where id = v_type.id;

  return jsonb_build_object(
    'order_id', v_order_id,
    'order_item_id', v_item_id,
    'merchant_reference', v_reference,
    'quantity', p_quantity,
    'subtotal_etb', v_subtotal,
    'buyer_service_fee_etb', v_fee,
    'total_etb', v_total,
    'amount_minor', round(v_total * 100)::bigint,
    'currency', 'ETB',
    'hold_expires_at', now() + interval '10 minutes'
  );
end;
$$;

grant execute on function public.create_order_hold(uuid,integer) to authenticated;

-- Immutable-per-order accounting snapshot. This is created only when the payment
-- completion RPC has moved the order to paid; retries cannot double-count revenue.
create or replace function public.record_tiqet_revenue_for_paid_order()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_org uuid;
  v_commission numeric(12,2);
  v_organiser_net numeric(12,2);
  v_newly_paid boolean := false;
  v_split_minor bigint;
begin
  -- Avoid reading OLD on an INSERT trigger invocation.
  if tg_op = 'INSERT' then
    v_newly_paid := (new.status = 'paid');
  else
    v_newly_paid := (new.status = 'paid' and old.status is distinct from 'paid');
  end if;

  if v_newly_paid then
    select e.organisation_id into v_org
      from public.order_items oi
      join public.events e on e.id = oi.event_id
      where oi.order_id = new.id
      order by oi.id limit 1;

    if new.subtotal_etb = 0 then
      -- Free claims have no organiser settlement or Tiqet fee.
      v_organiser_net := 0;
      v_commission := 0;
    else
      -- Use the exact split snapshot sent to Chapa at checkout, not a setting
      -- that could have changed between checkout creation and payment success.
      select nullif(p.provider_payload->>'organiser_split_minor','')::bigint
        into v_split_minor
        from public.payments p
        where p.order_id = new.id;

      if v_split_minor is null then
        raise exception 'Paid order is missing its stored Chapa organiser split';
      end if;

      v_organiser_net := least(new.subtotal_etb, greatest(0, round(v_split_minor::numeric / 100, 2)));
      v_commission := round(new.subtotal_etb - v_organiser_net, 2);
    end if;

    insert into public.platform_revenue_ledger(
      order_id, organisation_id, ticket_subtotal_etb,
      buyer_service_fee_etb, organiser_commission_etb,
      platform_gross_revenue_etb, organiser_net_settlement_etb
    ) values (
      new.id, v_org, new.subtotal_etb, new.fees_etb, v_commission,
      new.fees_etb + v_commission, v_organiser_net
    ) on conflict (order_id) do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_tiqet_revenue_on_paid on public.orders;
create trigger trg_tiqet_revenue_on_paid
  after insert or update of status on public.orders
  for each row execute function public.record_tiqet_revenue_for_paid_order();

-- Aggregate in PostgreSQL, not by fetching up to the REST API's row limit.
create or replace function public.get_tiqet_platform_revenue_summary()
returns jsonb
language sql
security definer
set search_path = ''
as $$
  with revenue as (
    select coalesce(sum(platform_gross_revenue_etb), 0)::numeric(14,2) as gross
    from public.platform_revenue_ledger
  ), payouts as (
    select
      coalesce(sum(amount_minor::numeric / 100) filter (where status in ('reserved','pending','succeeded','blocked','auth_needed','otp_needed')), 0)::numeric(14,2) as reserved,
      coalesce(sum(amount_minor::numeric / 100) filter (where status = 'succeeded'), 0)::numeric(14,2) as withdrawn,
      coalesce(sum(provider_service_fee_minor::numeric / 100) filter (where status = 'succeeded'), 0)::numeric(14,2) as payout_fees
    from public.platform_payouts
  )
  select jsonb_build_object(
    'gross_platform_revenue_etb', revenue.gross,
    'total_successful_withdrawals_etb', payouts.withdrawn,
    'successful_payout_fees_etb', payouts.payout_fees,
    'reserved_or_withdrawn_etb', payouts.reserved,
    'ledger_available_etb', greatest(0, revenue.gross - payouts.reserved),
    'currency', 'ETB'
  )
  from revenue cross join payouts;
$$;
revoke all on function public.get_tiqet_platform_revenue_summary() from public, anon, authenticated;
grant execute on function public.get_tiqet_platform_revenue_summary() to service_role;

-- Called only by the owner-authenticated Edge Function through the service role.
-- Advisory locking prevents simultaneous withdrawals from reserving the same earnings.
create or replace function public.reserve_tiqet_platform_payout(
  p_amount_minor bigint,
  p_bank_slug text,
  p_bank_name text,
  p_account_name text,
  p_account_number text
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_gross numeric(14,2);
  v_reserved numeric(14,2);
  v_requested numeric(14,2);
  v_reference text;
  v_id uuid;
begin
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext('tiqet_platform_payout_reserve'));
  if p_amount_minor is null or p_amount_minor < 100 then raise exception 'Minimum withdrawal is ETB 1.00'; end if;
  if p_bank_slug is null or length(trim(p_bank_slug)) = 0 then raise exception 'Choose a valid destination bank or wallet'; end if;
  if p_account_name is null or length(trim(p_account_name)) < 2 then raise exception 'Account holder name is required'; end if;
  if p_account_number is null or length(regexp_replace(p_account_number, '[^0-9]', '', 'g')) < 6 then raise exception 'Enter a valid destination account number'; end if;

  v_requested := round(p_amount_minor::numeric / 100, 2);
  select coalesce(sum(platform_gross_revenue_etb),0) into v_gross from public.platform_revenue_ledger;
  select coalesce(sum(amount_minor::numeric / 100),0) into v_reserved
    from public.platform_payouts
    where status in ('reserved','pending','succeeded','blocked','auth_needed','otp_needed');
  if v_requested > greatest(0, v_gross - v_reserved) then
    raise exception 'Withdrawal exceeds Tiqet revenue balance available in the ledger';
  end if;

  v_reference := 'TQP' || upper(substr(encode(extensions.gen_random_bytes(10),'hex'),1,17));
  insert into public.platform_payouts(
    amount_minor, bank_slug, bank_name, account_name, account_last4,
    merchant_reference, status
  ) values (
    p_amount_minor, trim(p_bank_slug), coalesce(nullif(trim(p_bank_name),''),trim(p_bank_slug)),
    trim(p_account_name), right(regexp_replace(p_account_number, '[^0-9]', '', 'g'),4),
    v_reference, 'reserved'
  ) returning id into v_id;

  return jsonb_build_object('id',v_id,'merchant_reference',v_reference,'amount_minor',p_amount_minor,'amount_etb',v_requested);
end;
$$;

revoke all on function public.reserve_tiqet_platform_payout(bigint,text,text,text,text) from public, anon, authenticated;
grant execute on function public.reserve_tiqet_platform_payout(bigint,text,text,text,text) to service_role;

commit;
