-- Tiqet V7.1 payment safety correction.
-- Apply AFTER 002_marketplace_monetization_and_cashout.sql.
-- This migration does NOT automate refunds or treat webhook notices as final refund verification.

begin;

-- An order moved to payment_review after a late/failed completion RPC must not
-- strand inventory. This marker makes release one-time and auditable.
alter table public.orders
  add column if not exists payment_review_inventory_released_at timestamptz;

create table if not exists public.payment_refund_alerts (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references public.payments(id) on delete restrict,
  order_id uuid not null references public.orders(id) on delete restrict,
  merchant_reference text not null,
  event_name text not null check (event_name in ('payment.partially_refunded','payment.fully_refunded')),
  provider_status text not null check (provider_status in ('partially_refunded','fully_refunded')),
  original_amount_minor bigint not null check (original_amount_minor > 0),
  refunded_amount_minor bigint not null check (refunded_amount_minor > 0 and refunded_amount_minor <= original_amount_minor),
  currency text not null check (currency = 'ETB'),
  payload_sha256 text not null unique,
  provider_payload jsonb not null default '{}'::jsonb,
  review_status text not null default 'manual_review'
    check (review_status in ('manual_review','reconciled','rejected')),
  received_at timestamptz not null default now(),
  reconciled_at timestamptz
);
create index if not exists payment_refund_alerts_order_idx
  on public.payment_refund_alerts(order_id, received_at desc);

alter table public.payment_refund_alerts enable row level security;
revoke all on public.payment_refund_alerts from anon, authenticated;
grant select, insert, update, delete on public.payment_refund_alerts to service_role;

-- Only called by the signed Chapa webhook after signature + payload checks.
-- It deliberately puts the ticket order into review (so the scanner blocks it),
-- but does NOT claim that funds are fully/partially reconciled or adjust revenue.
create or replace function public.record_chapa_refund_notice(
  p_merchant_reference text,
  p_payload_sha256 text,
  p_event_name text,
  p_provider_status text,
  p_original_amount_minor bigint,
  p_refunded_amount_minor bigint,
  p_currency text,
  p_provider_payload jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_payment public.payments%rowtype;
  v_order public.orders%rowtype;
  v_alert_id uuid;
begin
  if p_event_name is null or p_event_name not in ('payment.partially_refunded','payment.fully_refunded') then
    raise exception 'Unsupported refund event';
  end if;
  if p_provider_status is null or p_provider_status not in ('partially_refunded','fully_refunded') then
    raise exception 'Unsupported refund status';
  end if;
  if p_currency is distinct from 'ETB' or p_payload_sha256 is null or p_payload_sha256 !~ '^[a-f0-9]{64}$' then
    raise exception 'Invalid refund currency or payload digest';
  end if;
  if p_original_amount_minor is null or p_original_amount_minor <= 0
     or p_refunded_amount_minor is null or p_refunded_amount_minor <= 0
     or p_refunded_amount_minor > p_original_amount_minor then
    raise exception 'Invalid refund amount';
  end if;
  if p_event_name = 'payment.fully_refunded' and p_refunded_amount_minor <> p_original_amount_minor then
    raise exception 'Full refund amount does not match original payment';
  end if;
  if p_event_name = 'payment.partially_refunded' and p_refunded_amount_minor >= p_original_amount_minor then
    raise exception 'Partial refund amount is not partial';
  end if;

  select * into v_payment
    from public.payments
    where merchant_reference = p_merchant_reference
    for update;
  if not found then raise exception 'Payment reference not found'; end if;
  if v_payment.amount_minor <> p_original_amount_minor or v_payment.currency <> p_currency then
    raise exception 'Refund notice does not match original payment';
  end if;

  select * into v_order from public.orders where id = v_payment.order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_order.status not in ('paid','payment_review','refunded') then
    raise exception 'Refund notice received for an order not marked paid';
  end if;

  insert into public.payment_refund_alerts(
    payment_id, order_id, merchant_reference, event_name, provider_status,
    original_amount_minor, refunded_amount_minor, currency, payload_sha256, provider_payload
  ) values (
    v_payment.id, v_order.id, p_merchant_reference, p_event_name, p_provider_status,
    p_original_amount_minor, p_refunded_amount_minor, p_currency, p_payload_sha256,
    coalesce(p_provider_payload,'{}'::jsonb)
  ) on conflict (payload_sha256) do nothing
  returning id into v_alert_id;

  insert into public.webhook_events(provider, payload_sha256, merchant_reference)
  values ('chapa_refund', p_payload_sha256, p_merchant_reference)
  on conflict (provider, payload_sha256) do nothing;

  -- Keep the original payment and order in an exception state until an operator
  -- reconciles the refund against Chapa's refund reference/API and the ledger.
  update public.payments
    set status = 'review',
        provider_payload = coalesce(provider_payload,'{}'::jsonb) ||
          jsonb_build_object('refund_notice_received', true, 'latest_refund_event', p_event_name,
                             'latest_refunded_amount_minor', p_refunded_amount_minor),
        updated_at = now()
    where id = v_payment.id and status <> 'refunded';

  update public.orders set status = 'payment_review', updated_at = now()
    where id = v_order.id and status in ('paid','payment_review');

  return jsonb_build_object('recorded', true, 'duplicate', v_alert_id is null,
                            'order_id', v_order.id, 'manual_reconciliation_required', true);
end;
$$;
revoke all on function public.record_chapa_refund_notice(text,text,text,text,bigint,bigint,text,jsonb) from public, anon, authenticated;
grant execute on function public.record_chapa_refund_notice(text,text,text,text,bigint,bigint,text,jsonb) to service_role;

-- Late verified money after an expired hold must be flagged without leaking the
-- reserved stock. Existing expired/failed paths already released inventory, so
-- the release marker is only set/released for pending or legacy review states.
create or replace function public.flag_order_payment_for_review_and_release_hold(
  p_order_id uuid,
  p_provider_reference text,
  p_provider_payload jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_order public.orders%rowtype;
  v_payment public.payments%rowtype;
  v_item record;
  v_released boolean := false;
begin
  select * into v_order from public.orders where id = p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  select * into v_payment from public.payments where order_id = p_order_id for update;
  if not found then raise exception 'Payment record not found'; end if;

  if v_order.status = 'paid' then
    return jsonb_build_object('ok', true, 'already_paid', true, 'inventory_released', false);
  end if;

  if v_order.status in ('payment_pending','payment_review')
     and v_order.payment_review_inventory_released_at is null then
    for v_item in
      select ticket_type_id, sum(quantity)::integer as quantity
      from public.order_items where order_id = p_order_id group by ticket_type_id
    loop
      update public.ticket_types
        set quantity_reserved = greatest(0, quantity_reserved - v_item.quantity), updated_at = now()
        where id = v_item.ticket_type_id;
    end loop;
    update public.orders set payment_review_inventory_released_at = now() where id = p_order_id;
    v_released := true;
  end if;

  update public.orders set status = 'payment_review', updated_at = now()
    where id = p_order_id and status <> 'paid';
  update public.payments set
    status = 'review',
    provider_reference = coalesce(nullif(p_provider_reference,''), provider_reference),
    provider_payload = coalesce(provider_payload,'{}'::jsonb) || coalesce(p_provider_payload,'{}'::jsonb),
    verified_at = now(), updated_at = now()
    where id = v_payment.id and status <> 'refunded';

  return jsonb_build_object('ok', true, 'already_paid', false, 'inventory_released', v_released);
end;
$$;
revoke all on function public.flag_order_payment_for_review_and_release_hold(uuid,text,jsonb) from public, anon, authenticated;
grant execute on function public.flag_order_payment_for_review_and_release_hold(uuid,text,jsonb) to service_role;

-- The scanner must not accept tickets whose payment is under refund/reconciliation
-- review. Existing issued/duplicate checks remain atomic under the ticket row lock.
create or replace function public.checkin_ticket(
  p_ticket_token text,
  p_event_id uuid,
  p_device_reference text default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_ticket public.tickets%rowtype;
  v_order_status public.order_status;
  v_allowed boolean;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  select exists (
    select 1 from public.events e
    join public.organisations o on o.id = e.organisation_id
    where e.id = p_event_id and o.owner_id = v_user and o.status = 'verified'
    union all
    select 1 from public.event_staff es where es.event_id = p_event_id and es.user_id = v_user
  ) into v_allowed;
  if not v_allowed then raise exception 'You are not assigned to this event'; end if;

  select * into v_ticket from public.tickets
    where ticket_token = p_ticket_token and event_id = p_event_id for update;
  if not found then return jsonb_build_object('valid',false,'reason','ticket_not_found'); end if;
  if v_ticket.status = 'checked_in' then
    return jsonb_build_object('valid',false,'reason','already_checked_in','ticket_id',v_ticket.id);
  end if;
  if v_ticket.status <> 'issued' then
    return jsonb_build_object('valid',false,'reason','ticket_not_valid','ticket_id',v_ticket.id);
  end if;

  select status into v_order_status from public.orders where id = v_ticket.order_id;
  if v_order_status = 'payment_review' then
    return jsonb_build_object('valid',false,'reason','payment_under_review','ticket_id',v_ticket.id);
  end if;
  if v_order_status <> 'paid' then
    return jsonb_build_object('valid',false,'reason','order_not_paid','ticket_id',v_ticket.id);
  end if;

  update public.tickets set status = 'checked_in', checked_in_at = now() where id = v_ticket.id;
  insert into public.checkins(ticket_id,event_id,scanned_by,device_reference)
    values (v_ticket.id,p_event_id,v_user,p_device_reference);
  return jsonb_build_object('valid',true,'reason','checked_in','ticket_id',v_ticket.id);
end;
$$;
revoke all on function public.checkin_ticket(text,uuid,text) from public, anon;
grant execute on function public.checkin_ticket(text,uuid,text) to authenticated, service_role;

commit;
