-- Tiqet provider-agnostic payment core.
-- Apply AFTER migrations 001-004. This creates the common provider/account,
-- payment audit, organiser settlement-ledger and payout-request layers.
-- It does NOT activate an unapproved provider or move money by itself.

begin;

create table if not exists public.payment_provider_registry (
  provider text primary key check (provider ~ '^[a-z][a-z0-9_]{1,31}$'),
  display_name text not null,
  adapter_status text not null default 'contract_required'
    check (adapter_status in ('ready','contract_required','development_only','disabled')),
  checkout_enabled boolean not null default false,
  marketplace_split_supported boolean not null default false,
  organiser_payout_supported boolean not null default false,
  payment_methods jsonb not null default '[]'::jsonb check (jsonb_typeof(payment_methods) = 'array'),
  activation_notes text not null default '',
  updated_at timestamptz not null default now()
);

insert into public.payment_provider_registry(
  provider, display_name, adapter_status, checkout_enabled,
  marketplace_split_supported, organiser_payout_supported, activation_notes
) values
  ('chapa','Chapa','ready',true,true,true,
   'Adapter exists. Live marketplace use remains blocked until written marketplace approval, KYC and live credentials are confirmed.'),
  ('arifpay','ArifPay','contract_required',false,false,false,
   'Integration contract and current merchant sandbox credentials are required before enabling. Do not infer API paths or settlement behaviour.'),
  ('fenanpay','FenanPay','contract_required',false,false,false,
   'Integration contract, current API documentation and sandbox credentials are required before enabling.'),
  ('santimpay','SantimPay','contract_required',false,false,false,
   'Integration contract and verified marketplace settlement documentation are required before enabling.'),
  ('yagoutpay','YagoutPay','contract_required',false,false,false,
   'Integration contract and current API documentation are required before enabling.')
on conflict (provider) do update set
  display_name = excluded.display_name,
  adapter_status = excluded.adapter_status,
  checkout_enabled = excluded.checkout_enabled,
  marketplace_split_supported = excluded.marketplace_split_supported,
  organiser_payout_supported = excluded.organiser_payout_supported,
  activation_notes = excluded.activation_notes,
  updated_at = now();

alter table public.payment_provider_registry enable row level security;
revoke all on public.payment_provider_registry from anon, authenticated;
grant select, insert, update, delete on public.payment_provider_registry to service_role;

-- Replace the original single-provider CHECK with a provider registry FK.
alter table public.payments drop constraint if exists payments_provider_check;
alter table public.payments alter column provider set default 'chapa';
alter table public.payments
  add constraint payments_provider_format_check check (provider ~ '^[a-z][a-z0-9_]{1,31}$');
alter table public.payments
  add constraint payments_provider_registry_fk foreign key (provider)
  references public.payment_provider_registry(provider);

alter table public.payments
  add column if not exists provider_payment_reference text,
  add column if not exists idempotency_key text,
  add column if not exists payment_method text,
  add column if not exists failure_code text,
  add column if not exists failure_message text,
  add column if not exists refunded_amount_minor bigint not null default 0 check (refunded_amount_minor >= 0),
  add column if not exists last_verified_at timestamptz;
create unique index if not exists payments_provider_idempotency_idx
  on public.payments(provider, idempotency_key) where idempotency_key is not null;
create index if not exists payments_provider_reference_idx
  on public.payments(provider, provider_payment_reference) where provider_payment_reference is not null;

-- One organisation can connect a separate payout/settlement account at each provider.
-- Full bank/wallet account numbers must never be stored here.
create table if not exists public.organisation_payment_accounts (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete restrict,
  provider text not null references public.payment_provider_registry(provider),
  provider_account_reference text not null,
  destination_slug text,
  destination_name text,
  account_last4 text check (account_last4 is null or account_last4 ~ '^[0-9]{4}$'),
  currency text not null default 'ETB' check (currency = 'ETB'),
  status text not null default 'pending' check (status in ('pending','active','suspended','rejected')),
  provider_metadata jsonb not null default '{}'::jsonb,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organisation_id, provider),
  unique (provider, provider_account_reference)
);
create index if not exists organisation_payment_accounts_provider_idx
  on public.organisation_payment_accounts(provider, status, organisation_id);
alter table public.organisation_payment_accounts enable row level security;
revoke all on public.organisation_payment_accounts from anon, authenticated;
grant select, insert, update, delete on public.organisation_payment_accounts to service_role;

-- Preserve already-connected Chapa organisers when moving to the generic model.
insert into public.organisation_payment_accounts(
  organisation_id, provider, provider_account_reference, destination_slug,
  account_last4, status, verified_at, provider_metadata
)
select id, 'chapa', chapa_subaccount_reference, payout_method,
       payout_account_last4, 'active', payout_setup_at,
       jsonb_build_object('migrated_from_legacy_organisation_columns', true)
from public.organisations
where nullif(chapa_subaccount_reference,'') is not null
on conflict (organisation_id, provider) do nothing;

create table if not exists public.payment_attempt_events (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references public.payments(id) on delete restrict,
  order_id uuid not null references public.orders(id) on delete restrict,
  provider text not null references public.payment_provider_registry(provider),
  event_type text not null check (event_type in (
    'intent_created','checkout_created','checkout_failed','verification_started',
    'payment_succeeded','payment_failed','payment_review','refund_notice',
    'payout_requested','payout_updated','provider_error'
  )),
  provider_event_reference text,
  payload_digest text check (payload_digest is null or payload_digest ~ '^[a-f0-9]{64}$'),
  safe_metadata jsonb not null default '{}'::jsonb,
  occurred_at timestamptz not null default now(),
  unique (provider, payload_digest)
);
create index if not exists payment_attempt_events_order_idx
  on public.payment_attempt_events(order_id, occurred_at desc);
alter table public.payment_attempt_events enable row level security;
revoke all on public.payment_attempt_events from anon, authenticated;
grant select, insert, update, delete on public.payment_attempt_events to service_role;

-- Immutable organiser earnings ledger. This is an internal accounting record,
-- not a bank balance and not permission for Tiqet to custody customer funds.
create table if not exists public.organiser_settlement_ledger (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete restrict,
  order_id uuid references public.orders(id) on delete restrict,
  provider text not null references public.payment_provider_registry(provider),
  entry_type text not null check (entry_type in ('order_settlement','refund_adjustment','manual_adjustment','payout_debit','payout_reversal')),
  amount_minor bigint not null check (amount_minor <> 0),
  currency text not null default 'ETB' check (currency = 'ETB'),
  idempotency_key text not null unique,
  reference text,
  description text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists organiser_settlement_ledger_org_idx
  on public.organiser_settlement_ledger(organisation_id, created_at desc);
alter table public.organiser_settlement_ledger enable row level security;
revoke all on public.organiser_settlement_ledger from anon, authenticated;
grant select, insert, update, delete on public.organiser_settlement_ledger to service_role;

-- Backfill the settlement ledger from previously verified paid orders.
insert into public.organiser_settlement_ledger(
  organisation_id, order_id, provider, entry_type, amount_minor,
  idempotency_key, reference, description
)
select l.organisation_id, l.order_id, coalesce(p.provider,'chapa'), 'order_settlement',
       round(l.organiser_net_settlement_etb * 100)::bigint,
       'order-settlement:' || l.order_id::text, p.provider_reference,
       'Backfilled from pre-existing verified paid-order revenue ledger'
from public.platform_revenue_ledger l
left join public.payments p on p.order_id=l.order_id
where l.organiser_net_settlement_etb > 0 and l.organisation_id is not null
on conflict (idempotency_key) do nothing;

create table if not exists public.organiser_payout_requests (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete restrict,
  requested_by uuid not null references auth.users(id) on delete restrict,
  provider text not null references public.payment_provider_registry(provider),
  amount_minor bigint not null check (amount_minor >= 100),
  currency text not null default 'ETB' check (currency = 'ETB'),
  status text not null default 'requested'
    check (status in ('requested','approved','processing','paid','rejected','failed','reversed')),
  idempotency_key text not null unique,
  provider_reference text,
  operator_note text,
  reviewed_by uuid references auth.users(id) on delete restrict,
  reviewed_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists organiser_payout_requests_org_idx
  on public.organiser_payout_requests(organisation_id, created_at desc);
alter table public.organiser_payout_requests enable row level security;
revoke all on public.organiser_payout_requests from anon, authenticated;
grant select, insert, update, delete on public.organiser_payout_requests to service_role;

-- Add the organiser net amount using the immutable split snapshot saved at checkout.
-- A split snapshot is provider-neutral even though the current working adapter is Chapa.
create or replace function public.record_tiqet_revenue_for_paid_order()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_org uuid;
  v_commission numeric(12,2);
  v_organiser_net numeric(12,2);
  v_newly_paid boolean := false;
  v_split_minor bigint;
  v_provider text := 'chapa';
begin
  if tg_op = 'INSERT' then
    v_newly_paid := (new.status = 'paid');
  else
    v_newly_paid := (new.status = 'paid' and old.status is distinct from 'paid');
  end if;
  if v_newly_paid then
    select e.organisation_id into v_org
      from public.order_items oi join public.events e on e.id = oi.event_id
      where oi.order_id = new.id order by oi.id limit 1;
    select p.provider,
      coalesce(nullif(p.provider_payload->>'organiser_split_minor',''),
               nullif(p.provider_payload->>'settlement_split_minor',''))::bigint
      into v_provider, v_split_minor
      from public.payments p where p.order_id = new.id;
    if new.subtotal_etb = 0 then
      v_organiser_net := 0;
      v_commission := 0;
    else
      if v_split_minor is null then
        raise exception 'Paid order is missing its provider settlement split snapshot';
      end if;
      v_organiser_net := least(new.subtotal_etb, greatest(0, round(v_split_minor::numeric / 100, 2)));
      v_commission := round(new.subtotal_etb - v_organiser_net, 2);
    end if;
    insert into public.platform_revenue_ledger(
      order_id, organisation_id, ticket_subtotal_etb,
      buyer_service_fee_etb, organiser_commission_etb,
      platform_gross_revenue_etb, organiser_net_settlement_etb
    ) values (
      new.id, v_org, new.subtotal_etb, new.fees_etb, v_commission,
      new.fees_etb + v_commission, v_organiser_net
    ) on conflict (order_id) do nothing;

    if v_organiser_net > 0 and v_org is not null then
      insert into public.organiser_settlement_ledger(
        organisation_id, order_id, provider, entry_type, amount_minor,
        idempotency_key, reference, description
      ) values (
        v_org, new.id, coalesce(v_provider,'chapa'), 'order_settlement',
        round(v_organiser_net * 100)::bigint,
        'order-settlement:' || new.id::text,
        (select p.provider_reference from public.payments p where p.order_id = new.id),
        'Verified ticket-order settlement snapshot'
      ) on conflict (idempotency_key) do nothing;
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_tiqet_revenue_on_paid on public.orders;
create trigger trg_tiqet_revenue_on_paid
  after insert or update of status on public.orders
  for each row execute function public.record_tiqet_revenue_for_paid_order();

-- Rebuild a generic organiser balance from the append-only ledger and payout queue.
create or replace function public.get_my_organiser_settlement_summary(p_organisation_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_balance bigint;
  v_pending bigint;
  v_paid bigint;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if not exists (
    select 1 from public.organisations
    where id = p_organisation_id and owner_id = v_user and status = 'verified'
  ) then raise exception 'Verified organisation ownership required'; end if;
  select coalesce(sum(amount_minor),0)::bigint into v_balance
    from public.organiser_settlement_ledger where organisation_id = p_organisation_id;
  select
    coalesce(sum(amount_minor) filter (where status in ('requested','approved','processing')),0)::bigint,
    coalesce(sum(amount_minor) filter (where status = 'paid'),0)::bigint
    into v_pending, v_paid
    from public.organiser_payout_requests where organisation_id = p_organisation_id;
  return jsonb_build_object(
    'organisation_id',p_organisation_id,
    'currency','ETB',
    'earned_etb',round(v_balance::numeric / 100,2),
    'pending_payout_etb',round(v_pending::numeric / 100,2),
    'paid_out_etb',round(v_paid::numeric / 100,2),
    'available_etb',round(greatest(0,v_balance-v_pending)::numeric / 100,2),
    'note','Internal settlement ledger only; external funds are held and paid by the approved payment provider.'
  );
end;
$$;
revoke all on function public.get_my_organiser_settlement_summary(uuid) from public, anon;
grant execute on function public.get_my_organiser_settlement_summary(uuid) to authenticated, service_role;


create or replace function public.get_my_organiser_settlement_history(
  p_organisation_id uuid,
  p_limit integer default 30,
  p_offset integer default 0
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_rows jsonb;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_limit is null or p_limit < 1 or p_limit > 100 or p_offset is null or p_offset < 0 then
    raise exception 'Invalid history pagination';
  end if;
  if not exists (select 1 from public.organisations where id=p_organisation_id and owner_id=v_user and status='verified') then
    raise exception 'Verified organisation ownership required';
  end if;
  with items as (
    select jsonb_build_object(
      'id',l.id,'kind','ledger','entry_type',l.entry_type,'amount_minor',l.amount_minor,
      'amount_etb',round(l.amount_minor::numeric/100,2),'provider',l.provider,
      'reference',l.reference,'description',l.description,'created_at',l.created_at
    ) as item, l.created_at as sort_at
    from public.organiser_settlement_ledger l where l.organisation_id=p_organisation_id
      and l.entry_type not in ('payout_debit','payout_reversal')
    union all
    select jsonb_build_object(
      'id',r.id,'kind','payout_request','entry_type','payout_'||r.status,
      'amount_minor',case when r.status='reversed' then r.amount_minor else -r.amount_minor end,
      'amount_etb',round((case when r.status='reversed' then r.amount_minor else -r.amount_minor end)::numeric/100,2),
      'provider',r.provider,'reference',r.provider_reference,'description',coalesce(r.operator_note,'Organiser payout request'),
      'created_at',r.created_at
    ) as item, r.created_at as sort_at
    from public.organiser_payout_requests r where r.organisation_id=p_organisation_id
  )
  select coalesce(jsonb_agg(item order by sort_at desc),'[]'::jsonb) into v_rows
  from (select item,sort_at from items order by sort_at desc limit p_limit offset p_offset) page;
  return jsonb_build_object('organisation_id',p_organisation_id,'transactions',v_rows,'limit',p_limit,'offset',p_offset);
end;
$$;
revoke all on function public.get_my_organiser_settlement_history(uuid,integer,integer) from public, anon;
grant execute on function public.get_my_organiser_settlement_history(uuid,integer,integer) to authenticated, service_role;

-- Creates a payout request only. No money is transferred by this RPC. A request
-- remains unavailable for payment until an authorised operator/provider workflow approves it.
create or replace function public.request_organiser_payout(
  p_organisation_id uuid,
  p_amount_minor bigint,
  p_provider text,
  p_idempotency_key text
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_earned bigint;
  v_reserved bigint;
  v_id uuid;
  v_account public.organisation_payment_accounts%rowtype;
  v_provider public.payment_provider_registry%rowtype;
  v_existing public.organiser_payout_requests%rowtype;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_amount_minor is null or p_amount_minor < 100 then raise exception 'Minimum payout request is ETB 1.00'; end if;
  if p_idempotency_key is null or length(p_idempotency_key) not between 12 and 128 then raise exception 'A valid idempotency key is required'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext('tiqet_organiser_payout:' || p_organisation_id::text));
  if not exists (select 1 from public.organisations where id=p_organisation_id and owner_id=v_user and status='verified') then
    raise exception 'Verified organisation ownership required';
  end if;
  select * into v_existing from public.organiser_payout_requests where idempotency_key=p_idempotency_key;
  if found then
    if v_existing.organisation_id <> p_organisation_id or v_existing.amount_minor <> p_amount_minor or v_existing.provider <> p_provider then
      raise exception 'Idempotency key was already used for a different payout request';
    end if;
    return jsonb_build_object('request_id',v_existing.id,'status',v_existing.status,
      'amount_etb',round(v_existing.amount_minor::numeric/100,2),'duplicate',true);
  end if;
  select * into v_provider from public.payment_provider_registry where provider=p_provider;
  if not found or v_provider.adapter_status <> 'ready' or not v_provider.organiser_payout_supported then raise exception 'This provider does not have an approved organiser payout adapter'; end if;
  select * into v_account from public.organisation_payment_accounts
    where organisation_id=p_organisation_id and provider=p_provider and status='active';
  if not found then raise exception 'Connect and verify this provider settlement account first'; end if;
  select coalesce(sum(amount_minor),0)::bigint into v_earned
    from public.organiser_settlement_ledger where organisation_id=p_organisation_id;
  select coalesce(sum(amount_minor),0)::bigint into v_reserved
    from public.organiser_payout_requests
    where organisation_id=p_organisation_id and status in ('requested','approved','processing');
  if p_amount_minor > greatest(0,v_earned-v_reserved) then raise exception 'Payout request exceeds available organiser settlement balance'; end if;
  insert into public.organiser_payout_requests(
    organisation_id,requested_by,provider,amount_minor,idempotency_key
  ) values (p_organisation_id,v_user,p_provider,p_amount_minor,p_idempotency_key)
  on conflict (idempotency_key) do nothing returning id into v_id;
  if v_id is null then
    select id into v_id from public.organiser_payout_requests where idempotency_key=p_idempotency_key;
  end if;
  return jsonb_build_object('request_id',v_id,'status','requested','amount_etb',round(p_amount_minor::numeric/100,2),
    'note','Request recorded. This does not transfer funds or promise a payout date.');
end;
$$;
revoke all on function public.request_organiser_payout(uuid,bigint,text,text) from public, anon;
grant execute on function public.request_organiser_payout(uuid,bigint,text,text) to authenticated, service_role;

-- Only service_role can update payout state after provider confirmation and reconciliation.
create or replace function public.resolve_organiser_payout_request(
  p_request_id uuid,
  p_status text,
  p_provider_reference text default null,
  p_operator_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_row public.organiser_payout_requests%rowtype;
begin
  if auth.role() <> 'service_role' then raise exception 'Service role required'; end if;
  if p_status not in ('approved','processing','paid','rejected','failed','reversed') then raise exception 'Invalid payout status'; end if;
  select * into v_row from public.organiser_payout_requests where id=p_request_id for update;
  if not found then raise exception 'Payout request not found'; end if;
  if v_row.status='reversed' then raise exception 'Reversed payout state cannot be overwritten'; end if;
  if v_row.status='paid' and p_status<>'reversed' then raise exception 'Paid payout can only transition to a verified reversal'; end if;
  if p_status='reversed' and v_row.status<>'paid' then raise exception 'Only a paid payout can be reversed'; end if;
  update public.organiser_payout_requests set
    status=p_status,
    provider_reference=coalesce(nullif(p_provider_reference,''),provider_reference),
    operator_note=coalesce(nullif(p_operator_note,''),operator_note),
    reviewed_at=case when p_status in ('approved','rejected') then now() else reviewed_at end,
    completed_at=case when p_status in ('paid','failed','reversed') then now() else completed_at end,
    updated_at=now()
    where id=p_request_id;
  if p_status='paid' then
    insert into public.organiser_settlement_ledger(
      organisation_id,order_id,provider,entry_type,amount_minor,idempotency_key,reference,description
    ) values (
      v_row.organisation_id,null,v_row.provider,'payout_debit',-v_row.amount_minor,
      'organiser-payout-debit:'||v_row.id::text,v_row.provider_reference,'Confirmed organiser payout'
    ) on conflict (idempotency_key) do nothing;
  elsif p_status='reversed' then
    insert into public.organiser_settlement_ledger(
      organisation_id,order_id,provider,entry_type,amount_minor,idempotency_key,reference,description
    ) values (
      v_row.organisation_id,null,v_row.provider,'payout_reversal',v_row.amount_minor,
      'organiser-payout-reversal:'||v_row.id::text,v_row.provider_reference,'Confirmed organiser payout reversal'
    ) on conflict (idempotency_key) do nothing;
  end if;
  return jsonb_build_object('request_id',p_request_id,'status',p_status);
end;
$$;
revoke all on function public.resolve_organiser_payout_request(uuid,text,text,text) from public, anon, authenticated;
grant execute on function public.resolve_organiser_payout_request(uuid,text,text,text) to service_role;


-- Reconciliation ledgers preserve the original sale and record later refunds,
-- chargebacks and split reversals as signed adjustments rather than rewriting history.
create table if not exists public.platform_financial_adjustments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references public.orders(id) on delete restrict,
  payment_id uuid references public.payments(id) on delete restrict,
  provider text not null references public.payment_provider_registry(provider),
  adjustment_type text not null check (adjustment_type in ('refund','chargeback','split_reversal','manual_correction')),
  amount_minor bigint not null check (amount_minor <> 0),
  idempotency_key text not null unique,
  provider_reference text,
  description text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists platform_financial_adjustments_created_idx
  on public.platform_financial_adjustments(created_at desc);
alter table public.platform_financial_adjustments enable row level security;
revoke all on public.platform_financial_adjustments from anon, authenticated;
grant select, insert, update, delete on public.platform_financial_adjustments to service_role;

create table if not exists public.payment_reconciliation_adjustments (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references public.payments(id) on delete restrict,
  order_id uuid not null references public.orders(id) on delete restrict,
  provider text not null references public.payment_provider_registry(provider),
  adjustment_type text not null check (adjustment_type in ('refund','chargeback','split_reversal','manual_correction')),
  amount_minor bigint not null check (amount_minor > 0),
  platform_delta_minor bigint not null default 0,
  organiser_delta_minor bigint not null default 0,
  currency text not null default 'ETB' check (currency = 'ETB'),
  provider_reference text,
  idempotency_key text not null unique,
  status text not null default 'pending' check (status in ('pending','reconciled','rejected')),
  operator_note text,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  check (abs(platform_delta_minor) + abs(organiser_delta_minor) <= amount_minor)
);
create index if not exists payment_reconciliation_adjustments_order_idx
  on public.payment_reconciliation_adjustments(order_id, created_at desc);
alter table public.payment_reconciliation_adjustments enable row level security;
revoke all on public.payment_reconciliation_adjustments from anon, authenticated;
grant select, insert, update, delete on public.payment_reconciliation_adjustments to service_role;


-- Preserve the V7.1 provider-balance check but use net, adjusted platform revenue
-- so a refund/chargeback cannot leave the owner withdrawal ceiling overstated.
create or replace function public.reserve_tiqet_platform_payout(
  p_amount_minor bigint,
  p_bank_slug text,
  p_bank_name text,
  p_account_name text,
  p_account_number text,
  p_chapa_available_balance_minor bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_gross numeric(14,2);
  v_reserved numeric(14,2);
  v_provider_reserved bigint;
  v_requested numeric(14,2);
  v_reference text;
  v_id uuid;
begin
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtext('tiqet_platform_payout_reserve'));
  if p_amount_minor is null or p_amount_minor < 100 then raise exception 'Minimum withdrawal is ETB 1.00'; end if;
  if p_chapa_available_balance_minor is null or p_chapa_available_balance_minor < 0 then raise exception 'Could not verify the current Chapa available balance'; end if;
  if p_bank_slug is null or length(trim(p_bank_slug)) = 0 then raise exception 'Choose a valid destination bank or wallet'; end if;
  if p_account_name is null or length(trim(p_account_name)) < 2 then raise exception 'Account holder name is required'; end if;
  if p_account_number is null or length(regexp_replace(p_account_number, '[^0-9]', '', 'g')) < 6 then raise exception 'Enter a valid destination account number'; end if;

  v_requested := round(p_amount_minor::numeric / 100, 2);
  select coalesce((select sum(platform_gross_revenue_etb) from public.platform_revenue_ledger),0)
       + coalesce((select sum(amount_minor::numeric / 100) from public.platform_financial_adjustments),0)
    into v_gross;
  select coalesce(sum(amount_minor::numeric / 100),0) into v_reserved
    from public.platform_payouts
    where status in ('reserved','pending','succeeded','blocked','auth_needed','otp_needed');
  if v_requested > greatest(0,v_gross-v_reserved) then
    raise exception 'Withdrawal exceeds Tiqet net revenue available in the ledger';
  end if;
  select coalesce(sum(amount_minor),0)::bigint into v_provider_reserved
    from public.platform_payouts where status in ('reserved','pending','blocked','auth_needed','otp_needed');
  if p_amount_minor + v_provider_reserved > p_chapa_available_balance_minor then
    raise exception 'Withdrawal exceeds Chapa available balance after in-flight payout reservations';
  end if;
  v_reference := 'TQP' || upper(substr(encode(extensions.gen_random_bytes(10),'hex'),1,17));
  insert into public.platform_payouts(
    amount_minor,bank_slug,bank_name,account_name,account_last4,merchant_reference,status
  ) values (
    p_amount_minor,trim(p_bank_slug),coalesce(nullif(trim(p_bank_name),''),trim(p_bank_slug)),
    trim(p_account_name),right(regexp_replace(p_account_number,'[^0-9]','','g'),4),v_reference,'reserved'
  ) returning id into v_id;
  return jsonb_build_object('id',v_id,'merchant_reference',v_reference,'amount_minor',p_amount_minor,'amount_etb',v_requested);
end;
$$;
revoke all on function public.reserve_tiqet_platform_payout(bigint,text,text,text,text,bigint) from public, anon, authenticated;
grant execute on function public.reserve_tiqet_platform_payout(bigint,text,text,text,text,bigint) to service_role;

-- The original revenue ledger remains gross and immutable. The summary now subtracts
-- approved platform adjustments before calculating the owner withdrawal ceiling.
create or replace function public.get_tiqet_platform_revenue_summary()
returns jsonb
language sql
security definer
set search_path = ''
as $$
  with revenue as (
    select
      coalesce((select sum(platform_gross_revenue_etb) from public.platform_revenue_ledger),0)::numeric(14,2) as gross,
      coalesce((select sum(amount_minor::numeric / 100) from public.platform_financial_adjustments),0)::numeric(14,2) as adjustments
  ), payouts as (
    select
      coalesce(sum(amount_minor::numeric / 100) filter (where status in ('reserved','pending','succeeded','blocked','auth_needed','otp_needed')), 0)::numeric(14,2) as reserved,
      coalesce(sum(amount_minor::numeric / 100) filter (where status = 'succeeded'), 0)::numeric(14,2) as withdrawn,
      coalesce(sum(provider_service_fee_minor::numeric / 100) filter (where status = 'succeeded'), 0)::numeric(14,2) as payout_fees
    from public.platform_payouts
  )
  select jsonb_build_object(
    'gross_platform_revenue_etb', revenue.gross,
    'platform_adjustments_etb', revenue.adjustments,
    'net_platform_revenue_etb', greatest(0,revenue.gross + revenue.adjustments),
    'total_successful_withdrawals_etb', payouts.withdrawn,
    'successful_payout_fees_etb', payouts.payout_fees,
    'reserved_or_withdrawn_etb', payouts.reserved,
    'ledger_available_etb', greatest(0,revenue.gross + revenue.adjustments - payouts.reserved),
    'currency', 'ETB'
  )
  from revenue cross join payouts;
$$;
revoke all on function public.get_tiqet_platform_revenue_summary() from public, anon, authenticated;
grant execute on function public.get_tiqet_platform_revenue_summary() to service_role;

-- Record only a provider-confirmed and operator-reviewed adjustment here.
-- For a partial refund, the order remains in payment_review so tickets cannot be scanned
-- until an operator completes the ticket-level decision. A full refund revokes all tickets.
create or replace function public.reconcile_payment_adjustment(
  p_adjustment_id uuid,
  p_decision text,
  p_operator_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_adjustment public.payment_reconciliation_adjustments%rowtype;
  v_payment public.payments%rowtype;
  v_order public.orders%rowtype;
  v_refunded bigint;
begin
  if auth.role() <> 'service_role' then raise exception 'Service role required'; end if;
  if p_decision not in ('approve','reject') then raise exception 'Decision must be approve or reject'; end if;
  select * into v_adjustment from public.payment_reconciliation_adjustments
    where id=p_adjustment_id for update;
  if not found then raise exception 'Payment adjustment not found'; end if;
  if v_adjustment.status <> 'pending' then
    return jsonb_build_object('adjustment_id',v_adjustment.id,'status',v_adjustment.status,'duplicate',true);
  end if;
  if p_decision='reject' then
    update public.payment_reconciliation_adjustments set status='rejected',operator_note=p_operator_note,reviewed_at=now()
      where id=v_adjustment.id;
    return jsonb_build_object('adjustment_id',v_adjustment.id,'status','rejected');
  end if;

  select * into v_payment from public.payments where id=v_adjustment.payment_id for update;
  if not found then raise exception 'Payment record not found'; end if;
  select * into v_order from public.orders where id=v_adjustment.order_id for update;
  if not found or v_payment.order_id <> v_order.id or v_payment.provider <> v_adjustment.provider then
    raise exception 'Adjustment does not match its payment and order';
  end if;

  if v_adjustment.organiser_delta_minor <> 0 then
    insert into public.organiser_settlement_ledger(
      organisation_id,order_id,provider,entry_type,amount_minor,idempotency_key,reference,description
    )
    select e.organisation_id,v_order.id,v_adjustment.provider,'refund_adjustment',
      v_adjustment.organiser_delta_minor,
      'payment-adjustment-organiser:'||v_adjustment.id::text,
      v_adjustment.provider_reference,
      coalesce(p_operator_note,'Provider-confirmed payment reconciliation adjustment')
    from public.order_items oi join public.events e on e.id=oi.event_id
    where oi.order_id=v_order.id order by oi.id limit 1
    on conflict (idempotency_key) do nothing;
  end if;
  if v_adjustment.platform_delta_minor <> 0 then
    insert into public.platform_financial_adjustments(
      order_id,payment_id,provider,adjustment_type,amount_minor,idempotency_key,provider_reference,description
    ) values (
      v_order.id,v_payment.id,v_adjustment.provider,v_adjustment.adjustment_type,
      v_adjustment.platform_delta_minor,'payment-adjustment-platform:'||v_adjustment.id::text,
      v_adjustment.provider_reference,coalesce(p_operator_note,'Provider-confirmed platform reconciliation adjustment')
    ) on conflict (idempotency_key) do nothing;
  end if;

  if v_adjustment.adjustment_type='refund' then
    v_refunded := v_payment.refunded_amount_minor + v_adjustment.amount_minor;
    if v_refunded > v_payment.amount_minor then raise exception 'Refund total exceeds original payment'; end if;
    update public.payments set refunded_amount_minor=v_refunded,
      status=case when v_refunded=v_payment.amount_minor then 'refunded' else 'review' end,
      updated_at=now()
      where id=v_payment.id;
    if v_refunded=v_payment.amount_minor then
      update public.orders set status='refunded',updated_at=now() where id=v_order.id;
      update public.tickets set status='refunded' where order_id=v_order.id and status='issued';
    else
      update public.orders set status='payment_review',updated_at=now() where id=v_order.id and status<>'refunded';
    end if;
  else
    update public.payments set status='review',updated_at=now() where id=v_payment.id and status<>'refunded';
    update public.orders set status='payment_review',updated_at=now() where id=v_order.id and status<>'refunded';
  end if;

  update public.payment_reconciliation_adjustments set status='reconciled',operator_note=p_operator_note,reviewed_at=now()
    where id=v_adjustment.id;
  update public.payment_refund_alerts set review_status='reconciled',reconciled_at=now()
    where payment_id=v_payment.id and review_status='manual_review'
      and v_adjustment.adjustment_type='refund';
  return jsonb_build_object('adjustment_id',v_adjustment.id,'status','reconciled',
    'refunded_amount_minor',case when v_adjustment.adjustment_type='refund' then v_refunded else v_payment.refunded_amount_minor end,
    'full_refund',case when v_adjustment.adjustment_type='refund' then v_refunded=v_payment.amount_minor else false end);
end;
$$;
revoke all on function public.reconcile_payment_adjustment(uuid,text,text) from public, anon, authenticated;
grant execute on function public.reconcile_payment_adjustment(uuid,text,text) to service_role;

commit;
