-- Tiqet core schema. Apply once to a new Supabase project.
-- Currency values are ETB (birr). Chapa v2 amount is stored as minor units (1 birr = 100 santim).

begin;

create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

create type public.organisation_status as enum ('pending', 'verified', 'rejected', 'suspended');
create type public.event_status as enum ('draft', 'submitted', 'published', 'cancelled', 'archived');
create type public.order_status as enum ('payment_pending', 'paid', 'payment_failed', 'payment_review', 'expired', 'cancelled', 'refunded');
create type public.ticket_status as enum ('issued', 'checked_in', 'cancelled', 'refunded');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  preferred_language text not null default 'en' check (preferred_language in ('en','am')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organisations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete restrict,
  name text not null check (char_length(name) between 2 and 100),
  legal_name text not null check (char_length(legal_name) between 2 and 150),
  contact_phone text not null,
  status public.organisation_status not null default 'pending',
  verification_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index organisations_owner_idx on public.organisations(owner_id, created_at desc);

create table public.events (
  id uuid primary key default gen_random_uuid(),
  organisation_id uuid not null references public.organisations(id) on delete restrict,
  created_by uuid not null references public.profiles(id) on delete restrict,
  title text not null check (char_length(title) between 3 and 120),
  description text not null default '',
  category text not null,
  starts_at timestamptz not null,
  ends_at timestamptz,
  timezone text not null default 'Africa/Addis_Ababa',
  venue_name text not null,
  address text not null default '',
  city text not null default 'Addis Ababa',
  image_url text,
  status public.event_status not null default 'draft',
  approval_status text not null default 'pending' check (approval_status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at is null or ends_at > starts_at)
);
create index events_public_discovery_idx on public.events(status, approval_status, starts_at) where status = 'published' and approval_status = 'approved';
create index events_organisation_idx on public.events(organisation_id, created_at desc);

create table public.ticket_types (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 60),
  description text not null default '',
  price_etb numeric(12,2) not null check (price_etb >= 0),
  quantity_total integer not null check (quantity_total > 0),
  quantity_reserved integer not null default 0 check (quantity_reserved >= 0),
  quantity_sold integer not null default 0 check (quantity_sold >= 0),
  sales_start timestamptz,
  sales_end timestamptz,
  per_order_limit integer not null default 10 check (per_order_limit between 1 and 10),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (quantity_reserved + quantity_sold <= quantity_total),
  check (sales_end is null or sales_start is null or sales_end > sales_start)
);
create index ticket_types_event_idx on public.ticket_types(event_id);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.profiles(id) on delete restrict,
  status public.order_status not null default 'payment_pending',
  currency text not null default 'ETB' check (currency = 'ETB'),
  subtotal_etb numeric(12,2) not null check (subtotal_etb >= 0),
  fees_etb numeric(12,2) not null default 0 check (fees_etb >= 0),
  total_etb numeric(12,2) not null check (total_etb >= 0),
  merchant_reference text not null unique,
  hold_expires_at timestamptz not null,
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index orders_buyer_idx on public.orders(buyer_id, created_at desc);
create index orders_expiry_idx on public.orders(status, hold_expires_at) where status = 'payment_pending';

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  ticket_type_id uuid not null references public.ticket_types(id) on delete restrict,
  event_id uuid not null references public.events(id) on delete restrict,
  ticket_name_snapshot text not null,
  unit_price_etb numeric(12,2) not null check (unit_price_etb >= 0),
  quantity integer not null check (quantity between 1 and 10),
  line_total_etb numeric(12,2) not null check (line_total_etb >= 0)
);
create index order_items_order_idx on public.order_items(order_id);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete restrict,
  provider text not null default 'chapa' check (provider = 'chapa'),
  merchant_reference text not null unique,
  provider_reference text,
  checkout_url text,
  amount_minor bigint not null check (amount_minor > 0),
  currency text not null default 'ETB' check (currency = 'ETB'),
  status text not null default 'initiated' check (status in ('initiated','pending','succeeded','failed','review','cancelled','refunded')),
  provider_payload jsonb not null default '{}'::jsonb,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.tickets (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  order_item_id uuid not null references public.order_items(id) on delete restrict,
  event_id uuid not null references public.events(id) on delete restrict,
  buyer_id uuid not null references public.profiles(id) on delete restrict,
  ticket_type_id uuid not null references public.ticket_types(id) on delete restrict,
  ticket_token text not null unique default encode(extensions.gen_random_bytes(32), 'hex'),
  status public.ticket_status not null default 'issued',
  issued_at timestamptz not null default now(),
  checked_in_at timestamptz
);
create index tickets_buyer_idx on public.tickets(buyer_id, issued_at desc);
create index tickets_event_idx on public.tickets(event_id, status);

create table public.event_staff (
  event_id uuid not null references public.events(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  assigned_by uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  primary key(event_id, user_id)
);

create table public.checkins (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null unique references public.tickets(id) on delete restrict,
  event_id uuid not null references public.events(id) on delete restrict,
  scanned_by uuid not null references public.profiles(id) on delete restrict,
  scanned_at timestamptz not null default now(),
  device_reference text
);

create table public.webhook_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  payload_sha256 text not null,
  merchant_reference text,
  received_at timestamptz not null default now(),
  unique(provider, payload_sha256)
);

-- New Auth users get a profile row automatically.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles(id, full_name, phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    nullif(new.raw_user_meta_data ->> 'phone', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Create a locked inventory hold. This is the only client-callable way to create a pending order.
create or replace function public.create_order_hold(p_ticket_type_id uuid, p_quantity integer)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_type public.ticket_types%rowtype;
  v_event public.events%rowtype;
  v_order_id uuid;
  v_reference text;
  v_total numeric(12,2);
  v_item_id uuid;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_quantity is null or p_quantity < 1 or p_quantity > 10 then raise exception 'Quantity must be between 1 and 10'; end if;

  -- Expire stale holds for this ticket type before checking capacity.
  for v_order_id in
    select o.id from public.orders o
    join public.order_items oi on oi.order_id = o.id
    where oi.ticket_type_id = p_ticket_type_id
      and o.status = 'payment_pending'
      and o.hold_expires_at <= now()
    for update of o
  loop
    update public.orders set status = 'expired', updated_at = now() where id = v_order_id and status = 'payment_pending';
    update public.ticket_types t
      set quantity_reserved = greatest(0, t.quantity_reserved - coalesce((select sum(oi.quantity) from public.order_items oi where oi.order_id = v_order_id and oi.ticket_type_id = t.id),0)),
          updated_at = now()
      where t.id = p_ticket_type_id;
  end loop;

  select * into v_type from public.ticket_types where id = p_ticket_type_id for update;
  if not found then raise exception 'Ticket type not found'; end if;
  select * into v_event from public.events where id = v_type.event_id;
  if v_event.status <> 'published' or v_event.approval_status <> 'approved' then raise exception 'Event is not available for sale'; end if;
  if v_type.sales_start is not null and v_type.sales_start > now() then raise exception 'Ticket sales have not started'; end if;
  if v_type.sales_end is not null and v_type.sales_end <= now() then raise exception 'Ticket sales have ended'; end if;
  if p_quantity > v_type.per_order_limit then raise exception 'Quantity exceeds the per-order limit'; end if;
  if (v_type.quantity_total - v_type.quantity_reserved - v_type.quantity_sold) < p_quantity then raise exception 'Not enough tickets are available'; end if;

  v_total := v_type.price_etb * p_quantity;
  v_order_id := gen_random_uuid();
  v_reference := 'TQ' || upper(substr(encode(extensions.gen_random_bytes(12),'hex'),1,18));

  insert into public.orders(id, buyer_id, status, subtotal_etb, fees_etb, total_etb, merchant_reference, hold_expires_at)
  values (v_order_id, v_user, 'payment_pending', v_total, 0, v_total, v_reference, now() + interval '10 minutes');

  insert into public.order_items(order_id, ticket_type_id, event_id, ticket_name_snapshot, unit_price_etb, quantity, line_total_etb)
  values (v_order_id, v_type.id, v_event.id, v_type.name, v_type.price_etb, p_quantity, v_total)
  returning id into v_item_id;

  update public.ticket_types
    set quantity_reserved = quantity_reserved + p_quantity, updated_at = now()
    where id = v_type.id;

  return jsonb_build_object(
    'order_id', v_order_id,
    'order_item_id', v_item_id,
    'merchant_reference', v_reference,
    'quantity', p_quantity,
    'total_etb', v_total,
    'amount_minor', round(v_total * 100)::bigint,
    'currency', 'ETB',
    'hold_expires_at', now() + interval '10 minutes'
  );
end;
$$;

-- Free ticket claims bypass the payment provider but still use an inventory lock and server-issued tokens.
create or replace function public.claim_free_tickets(p_ticket_type_id uuid, p_quantity integer)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_type public.ticket_types%rowtype;
  v_event public.events%rowtype;
  v_order_id uuid := gen_random_uuid();
  v_reference text;
  v_item_id uuid;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_quantity is null or p_quantity < 1 or p_quantity > 10 then raise exception 'Quantity must be between 1 and 10'; end if;
  select * into v_type from public.ticket_types where id=p_ticket_type_id for update;
  if not found then raise exception 'Ticket type not found'; end if;
  if v_type.price_etb <> 0 then raise exception 'This ticket type requires payment'; end if;
  select * into v_event from public.events where id=v_type.event_id;
  if v_event.status <> 'published' or v_event.approval_status <> 'approved' then raise exception 'Event is not available'; end if;
  if v_type.sales_start is not null and v_type.sales_start > now() then raise exception 'Ticket sales have not started'; end if;
  if v_type.sales_end is not null and v_type.sales_end <= now() then raise exception 'Ticket sales have ended'; end if;
  if p_quantity > v_type.per_order_limit then raise exception 'Quantity exceeds the per-order limit'; end if;
  if (v_type.quantity_total - v_type.quantity_reserved - v_type.quantity_sold) < p_quantity then raise exception 'Not enough tickets are available'; end if;

  v_reference := 'TQF' || upper(substr(encode(extensions.gen_random_bytes(12),'hex'),1,17));
  insert into public.orders(id,buyer_id,status,currency,subtotal_etb,fees_etb,total_etb,merchant_reference,hold_expires_at,paid_at)
  values(v_order_id,v_user,'paid','ETB',0,0,0,v_reference,now(),now());
  insert into public.order_items(order_id,ticket_type_id,event_id,ticket_name_snapshot,unit_price_etb,quantity,line_total_etb)
  values(v_order_id,v_type.id,v_event.id,v_type.name,0,p_quantity,0)
  returning id into v_item_id;
  update public.ticket_types set quantity_sold=quantity_sold+p_quantity,updated_at=now() where id=v_type.id;
  insert into public.tickets(order_id,order_item_id,event_id,buyer_id,ticket_type_id)
    select v_order_id,v_item_id,v_event.id,v_user,v_type.id from generate_series(1,p_quantity);
  return jsonb_build_object('ok',true,'order_id',v_order_id,'tickets_issued',p_quantity);
end;
$$;

-- Server-only payment completion. Repeated calls are safe and never issue duplicate tickets.
create or replace function public.complete_order_payment(
  p_order_id uuid,
  p_provider_reference text,
  p_merchant_reference text,
  p_amount_minor bigint,
  p_currency text,
  p_provider_payload jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_order public.orders%rowtype;
  v_payment public.payments%rowtype;
  v_item record;
  v_ticket_count integer := 0;
begin
  select * into v_order from public.orders where id = p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if v_order.merchant_reference <> p_merchant_reference then raise exception 'Merchant reference mismatch'; end if;
  if v_order.currency <> p_currency then raise exception 'Currency mismatch'; end if;
  if round(v_order.total_etb * 100)::bigint <> p_amount_minor then raise exception 'Amount mismatch'; end if;

  select * into v_payment from public.payments where order_id = v_order.id for update;
  if not found then raise exception 'Payment record not found'; end if;
  if v_order.status = 'paid' then
    return jsonb_build_object('ok', true, 'already_processed', true, 'order_id', v_order.id);
  end if;
  if v_order.status <> 'payment_pending' or v_order.hold_expires_at < now() then raise exception 'Order hold is no longer valid'; end if;

  update public.orders set status = 'paid', paid_at = now(), updated_at = now() where id = v_order.id;
  update public.payments set status = 'succeeded', provider_reference = p_provider_reference,
    provider_payload = coalesce(p_provider_payload,'{}'::jsonb), verified_at = now(), updated_at = now()
    where order_id = v_order.id;

  for v_item in select * from public.order_items where order_id = v_order.id loop
    update public.ticket_types set
      quantity_reserved = greatest(0, quantity_reserved - v_item.quantity),
      quantity_sold = quantity_sold + v_item.quantity,
      updated_at = now()
    where id = v_item.ticket_type_id;

    insert into public.tickets(order_id, order_item_id, event_id, buyer_id, ticket_type_id)
    select v_order.id, v_item.id, v_item.event_id, v_order.buyer_id, v_item.ticket_type_id
    from generate_series(1, v_item.quantity);
    v_ticket_count := v_ticket_count + v_item.quantity;
  end loop;

  return jsonb_build_object('ok', true, 'already_processed', false, 'order_id', v_order.id, 'tickets_issued', v_ticket_count);
end;
$$;

create or replace function public.fail_order_payment(p_order_id uuid, p_reason text default 'payment_failed')
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_order public.orders%rowtype;
  v_item record;
begin
  select * into v_order from public.orders where id = p_order_id for update;
  if not found or v_order.status <> 'payment_pending' then return; end if;
  update public.orders set status = 'payment_failed', updated_at = now() where id = p_order_id;
  update public.payments set status = 'failed', provider_payload = jsonb_build_object('failure_reason',p_reason), updated_at = now() where order_id = p_order_id;
  for v_item in select * from public.order_items where order_id = p_order_id loop
    update public.ticket_types set quantity_reserved = greatest(0, quantity_reserved - v_item.quantity), updated_at = now() where id = v_item.ticket_type_id;
  end loop;
end;
$$;

create or replace function public.submit_event_for_review(p_event_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_event public.events%rowtype;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  select e.* into v_event
  from public.events e
  join public.organisations o on o.id=e.organisation_id
  where e.id=p_event_id and e.created_by=v_user and o.owner_id=v_user and o.status='verified'
  for update of e;
  if not found then raise exception 'Verified organiser event not found'; end if;
  if v_event.status <> 'draft' then raise exception 'Only draft events can be submitted'; end if;
  if not exists (select 1 from public.ticket_types t where t.event_id=p_event_id) then
    raise exception 'Add at least one ticket type before submitting';
  end if;
  update public.events set status='submitted', updated_at=now() where id=p_event_id;
  return jsonb_build_object('event_id',p_event_id,'status','submitted');
end;
$$;

create or replace function public.checkin_ticket(p_ticket_token text, p_event_id uuid, p_device_reference text default null)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_ticket public.tickets%rowtype;
  v_allowed boolean;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  select exists (
    select 1 from public.events e
    join public.organisations o on o.id = e.organisation_id
    where e.id = p_event_id and o.owner_id = v_user and o.status = 'verified'
    union all
    select 1 from public.event_staff es where es.event_id = p_event_id and es.user_id = v_user
  ) into v_allowed;
  if not v_allowed then raise exception 'You are not assigned to this event'; end if;

  select * into v_ticket from public.tickets where ticket_token = p_ticket_token and event_id = p_event_id for update;
  if not found then return jsonb_build_object('valid',false,'reason','ticket_not_found'); end if;
  if v_ticket.status = 'checked_in' then return jsonb_build_object('valid',false,'reason','already_checked_in','ticket_id',v_ticket.id); end if;
  if v_ticket.status <> 'issued' then return jsonb_build_object('valid',false,'reason','ticket_not_valid','ticket_id',v_ticket.id); end if;

  update public.tickets set status = 'checked_in', checked_in_at = now() where id = v_ticket.id;
  insert into public.checkins(ticket_id,event_id,scanned_by,device_reference) values (v_ticket.id,p_event_id,v_user,p_device_reference);
  return jsonb_build_object('valid',true,'reason','checked_in','ticket_id',v_ticket.id);
end;
$$;

-- Create an event, its first ticket type, and submit it for review in one transaction.
-- This prevents partially-created events if a later client request fails.
create or replace function public.create_event_submission(
  p_organisation_id uuid, p_title text, p_description text, p_category text,
  p_starts_at timestamptz, p_venue_name text, p_address text, p_city text,
  p_ticket_name text, p_price_etb numeric, p_quantity integer
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_event_id uuid := gen_random_uuid();
  v_ticket_type_id uuid := gen_random_uuid();
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if not exists (select 1 from public.organisations o where o.id=p_organisation_id and o.owner_id=v_user and o.status='verified') then
    raise exception 'A verified organisation is required';
  end if;
  if p_title is null or char_length(trim(p_title)) not between 3 and 120 then raise exception 'Event title must be between 3 and 120 characters'; end if;
  if p_category is null or char_length(trim(p_category))=0 then raise exception 'Event category is required'; end if;
  if p_starts_at is null or p_starts_at <= now() then raise exception 'Choose a future event date and time'; end if;
  if p_venue_name is null or char_length(trim(p_venue_name)) < 2 then raise exception 'Venue name is required'; end if;
  if p_ticket_name is null or char_length(trim(p_ticket_name)) not between 2 and 60 then raise exception 'Ticket name must be between 2 and 60 characters'; end if;
  if p_price_etb is null or p_price_etb < 0 then raise exception 'Ticket price cannot be negative'; end if;
  if p_quantity is null or p_quantity < 1 or p_quantity > 100000 then raise exception 'Ticket quantity must be between 1 and 100000'; end if;

  insert into public.events(id,organisation_id,created_by,title,description,category,starts_at,venue_name,address,city,status,approval_status)
  values(v_event_id,p_organisation_id,v_user,trim(p_title),coalesce(p_description,''),trim(p_category),p_starts_at,trim(p_venue_name),coalesce(trim(p_address),''),coalesce(nullif(trim(p_city),''),'Addis Ababa'),'submitted','pending');

  insert into public.ticket_types(id,event_id,name,price_etb,quantity_total,per_order_limit)
  values(v_ticket_type_id,v_event_id,trim(p_ticket_name),round(p_price_etb,2),p_quantity,least(p_quantity,10));

  return jsonb_build_object('event_id',v_event_id,'ticket_type_id',v_ticket_type_id,'status','submitted','approval_status','pending');
end;
$$;

-- RLS: all client access is scoped to the signed-in user or approved public event listings.
alter table public.profiles enable row level security;
alter table public.organisations enable row level security;
alter table public.events enable row level security;
alter table public.ticket_types enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.tickets enable row level security;
alter table public.event_staff enable row level security;
alter table public.checkins enable row level security;
alter table public.webhook_events enable row level security;

create policy profiles_read_self on public.profiles for select to authenticated using (id = auth.uid());
create policy profiles_update_self on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy organisations_read_owner on public.organisations for select to authenticated using (owner_id = auth.uid());
create policy organisations_apply on public.organisations for insert to authenticated with check (owner_id = auth.uid() and status = 'pending');

create policy events_public_read on public.events for select to anon, authenticated
  using (status = 'published' and approval_status = 'approved');
create policy events_owner_read on public.events for select to authenticated
  using (exists (select 1 from public.organisations o where o.id = organisation_id and o.owner_id = auth.uid()));
create policy events_verified_org_insert on public.events for insert to authenticated
  with check (created_by = auth.uid() and status = 'draft' and approval_status = 'pending'
    and exists (select 1 from public.organisations o where o.id = organisation_id and o.owner_id = auth.uid() and o.status = 'verified'));
create policy events_verified_org_update on public.events for update to authenticated
  using (exists (select 1 from public.organisations o where o.id = organisation_id and o.owner_id = auth.uid() and o.status = 'verified'))
  with check (created_by = auth.uid() and status in ('draft','submitted') and approval_status = 'pending');

create policy ticket_types_public_read on public.ticket_types for select to anon, authenticated
  using (exists (select 1 from public.events e where e.id = event_id and e.status = 'published' and e.approval_status = 'approved'));
create policy ticket_types_owner_read on public.ticket_types for select to authenticated
  using (exists (select 1 from public.events e join public.organisations o on o.id=e.organisation_id where e.id=event_id and o.owner_id=auth.uid()));
create policy ticket_types_verified_owner_manage on public.ticket_types for all to authenticated
  using (exists (select 1 from public.events e join public.organisations o on o.id=e.organisation_id where e.id=event_id and o.owner_id=auth.uid() and o.status='verified' and e.status='draft'))
  with check (exists (select 1 from public.events e join public.organisations o on o.id=e.organisation_id where e.id=event_id and o.owner_id=auth.uid() and o.status='verified' and e.status='draft'));

create policy orders_read_buyer on public.orders for select to authenticated using (buyer_id = auth.uid());
create policy order_items_read_buyer on public.order_items for select to authenticated using (exists (select 1 from public.orders o where o.id=order_id and o.buyer_id=auth.uid()));
create policy tickets_read_buyer on public.tickets for select to authenticated using (buyer_id = auth.uid());
create policy payments_read_buyer on public.payments for select to authenticated using (exists (select 1 from public.orders o where o.id=order_id and o.buyer_id=auth.uid()));
create policy event_staff_read_assigned on public.event_staff for select to authenticated using (user_id=auth.uid());
create policy checkins_read_staff_or_owner on public.checkins for select to authenticated using (
  scanned_by=auth.uid() or exists (select 1 from public.events e join public.organisations o on o.id=e.organisation_id where e.id=event_id and o.owner_id=auth.uid())
);

-- Only the signed-in buyer can create an inventory hold. Payment completion/failure is service-role-only.
revoke all on function public.complete_order_payment(uuid,text,text,bigint,text,jsonb) from public, anon, authenticated;
revoke all on function public.fail_order_payment(uuid,text) from public, anon, authenticated;
grant execute on function public.create_order_hold(uuid,integer) to authenticated;
grant execute on function public.claim_free_tickets(uuid,integer) to authenticated;
grant execute on function public.checkin_ticket(text,uuid,text) to authenticated;
grant execute on function public.submit_event_for_review(uuid) to authenticated;
grant execute on function public.create_event_submission(uuid,text,text,text,timestamptz,text,text,text,text,numeric,integer) to authenticated;
grant execute on function public.complete_order_payment(uuid,text,text,bigint,text,jsonb) to service_role;
grant execute on function public.fail_order_payment(uuid,text) to service_role;

-- Browser/mobile clients cannot directly mutate transaction state or mint tickets.
revoke insert, update, delete on public.orders, public.order_items, public.payments, public.tickets, public.checkins, public.webhook_events from anon, authenticated;
revoke insert, update, delete on public.profiles from anon, authenticated;
grant select on public.profiles, public.organisations, public.events, public.ticket_types, public.orders, public.order_items, public.payments, public.tickets, public.event_staff, public.checkins to authenticated;
grant select on public.events, public.ticket_types to anon;
grant update(full_name, phone, preferred_language, updated_at) on public.profiles to authenticated;
grant insert on public.organisations to authenticated;
grant insert on public.events to authenticated;
grant update(title, description, category, starts_at, ends_at, venue_name, address, city, image_url, updated_at) on public.events to authenticated;
grant insert, update, delete on public.ticket_types to authenticated;

commit;
