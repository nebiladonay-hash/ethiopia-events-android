import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.1'

function hex(bytes: Uint8Array): string {
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('')
}

function constantTimeEqual(a: string, b: string): boolean {
  if (!/^[a-f0-9]{64}$/i.test(a) || !/^[a-f0-9]{64}$/i.test(b)) return false
  let diff = 0
  for (let i = 0; i < 64; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i)
  return diff === 0
}

async function hmacSha256(secret: string, rawBytes: Uint8Array): Promise<string> {
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'],
  )
  const signature = await crypto.subtle.sign('HMAC', key, rawBytes)
  return hex(new Uint8Array(signature))
}

async function sha256(rawBytes: Uint8Array): Promise<string> {
  return hex(new Uint8Array(await crypto.subtle.digest('SHA-256', rawBytes)))
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

  const rawBytes = new Uint8Array(await req.arrayBuffer())
  const rawBody = new TextDecoder().decode(rawBytes)
  const received = req.headers.get('x-chapa-signature') ?? ''
  const webhookSecret = Deno.env.get('CHAPA_WEBHOOK_SECRET')
  const chapaPrivateKey = Deno.env.get('CHAPA_PRIVATE_KEY')
  if (!webhookSecret || !chapaPrivateKey) return json({ error: 'Webhook is not configured' }, 503)

  // Chapa v2 signs the exact raw request body with HMAC-SHA256.
  const expected = await hmacSha256(webhookSecret, rawBytes)
  if (!constantTimeEqual(received.toLowerCase(), expected.toLowerCase())) {
    return json({ error: 'Invalid webhook signature' }, 401)
  }

  let event: Record<string, unknown>
  try {
    event = JSON.parse(rawBody)
  } catch {
    return json({ error: 'Invalid JSON' }, 400)
  }
  if (event.webhook_type !== 'payment') return json({ received: true, ignored: true })

  const expectedMode = Deno.env.get('CHAPA_MODE')
  if (expectedMode && event.mode && String(event.mode).toLowerCase() !== expectedMode.toLowerCase()) {
    return json({ error: 'Webhook environment does not match this deployment' }, 401)
  }

  const merchantReference = String(event.merchant_reference ?? '')
  const chapaReference = String(event.chapa_reference ?? '')
  if (!merchantReference) return json({ error: 'Missing merchant reference' }, 400)

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  const admin = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  })
  const { data: payment, error: paymentError } = await admin
    .from('payments')
    .select('id, order_id, merchant_reference, amount_minor, currency, status')
    .eq('merchant_reference', merchantReference)
    .maybeSingle()
  if (paymentError || !payment) return json({ error: 'Payment reference not found' }, 404)

  // A webhook is only a notification. Re-query Chapa before issuing any tickets.
  const verificationReference = chapaReference || merchantReference
  const verifyResponse = await fetch(
    `https://api.chapa.global/v2/payments/${encodeURIComponent(verificationReference)}/verify`,
    { headers: { Authorization: `Bearer ${chapaPrivateKey}` } },
  )
  const verified = await verifyResponse.json().catch(() => ({}))
  const details = verified?.data
  if (!verifyResponse.ok || verified?.status !== 'success' || details?.status !== 'SUCCESS') {
    if (event.status === 'failed' || event.status === 'cancelled') {
      await admin.rpc('fail_order_payment', { p_order_id: payment.order_id, p_reason: String(event.status) })
    }
    return json({ received: true, verified: false })
  }

  const amount = Number(details.amount)
  const currency = String(details.currency ?? '')
  const verifiedMerchantReference = String(details.merchant_reference ?? '')
  if (
    !Number.isFinite(amount) ||
    amount !== Number(payment.amount_minor) ||
    currency !== payment.currency ||
    verifiedMerchantReference !== payment.merchant_reference
  ) {
    return json({ error: 'Verified payment does not match the pending order' }, 409)
  }

  const { error: completeError } = await admin.rpc('complete_order_payment', {
    p_order_id: payment.order_id,
    p_provider_reference: String(details.chapa_reference ?? chapaReference),
    p_merchant_reference: verifiedMerchantReference,
    p_amount_minor: amount,
    p_currency: currency,
    p_provider_payload: verified,
  })
  if (completeError) {
    // The money may have moved after the inventory hold expired. Do not mint tickets
    // or ask Chapa to retry indefinitely; flag it for an operator refund/reconciliation.
    await admin.from('orders').update({ status: 'payment_review', updated_at: new Date().toISOString() }).eq('id', payment.order_id)
    await admin.from('payments').update({ status: 'review', provider_reference: String(details.chapa_reference ?? chapaReference), provider_payload: verified, verified_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq('id', payment.id)
    const payloadHash = await sha256(rawBytes)
    await admin.from('webhook_events').upsert({ provider: 'chapa', payload_sha256: payloadHash, merchant_reference: merchantReference }, { onConflict: 'provider,payload_sha256', ignoreDuplicates: true })
    return json({ received: true, verified: true, needs_manual_review: true })
  }

  // Recording the delivery is itself idempotent; the completion RPC is also idempotent.
  const payloadHash = await sha256(rawBytes)
  await admin.from('webhook_events').upsert({
    provider: 'chapa',
    payload_sha256: payloadHash,
    merchant_reference: merchantReference,
  }, { onConflict: 'provider,payload_sha256', ignoreDuplicates: true })

  return json({ received: true, verified: true })
})
