import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

  const authHeader = req.headers.get('Authorization')
  if (!authHeader?.startsWith('Bearer ')) return json({ error: 'Sign-in required' }, 401)

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  const chapaKey = Deno.env.get('CHAPA_PRIVATE_KEY')
  if (!chapaKey) return json({ error: 'Payment provider is not configured' }, 503)

  const userClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: authHeader } },
    auth: { persistSession: false, autoRefreshToken: false },
  })
  const admin = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  })

  const { data: userResult, error: userError } = await userClient.auth.getUser()
  if (userError || !userResult.user) return json({ error: 'Invalid or expired session' }, 401)

  let body: { ticket_type_id?: string; quantity?: number }
  try {
    body = await req.json()
  } catch {
    return json({ error: 'Invalid JSON body' }, 400)
  }
  if (!body.ticket_type_id || !Number.isInteger(body.quantity)) {
    return json({ error: 'ticket_type_id and integer quantity are required' }, 400)
  }

  // The database locks the ticket-type row and reserves inventory atomically.
  const { data: hold, error: holdError } = await userClient.rpc('create_order_hold', {
    p_ticket_type_id: body.ticket_type_id,
    p_quantity: body.quantity,
  })
  if (holdError || !hold?.order_id) return json({ error: holdError?.message ?? 'Could not reserve tickets' }, 409)

  const { data: profile } = await admin
    .from('profiles')
    .select('full_name, phone')
    .eq('id', userResult.user.id)
    .maybeSingle()

  const nameParts = (profile?.full_name ?? '').trim().split(/\s+/).filter(Boolean)
  const customer: Record<string, string> = {
    email: userResult.user.email ?? '',
  }
  if (nameParts.length) customer.first_name = nameParts[0]
  if (nameParts.length > 1) customer.last_name = nameParts.slice(1).join(' ')
  if (profile?.phone) customer.phone_number = profile.phone

  const chapaResponse = await fetch('https://api.chapa.global/v2/payments/hosted', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${chapaKey}`,
      'Content-Type': 'application/json',
      // Reusing the order reference makes retries of the same hold idempotent.
      'Idempotency-Key': hold.merchant_reference,
    },
    body: JSON.stringify({
      amount: hold.amount_minor,
      currency: 'ETB',
      merchant_reference: hold.merchant_reference,
      customer,
      meta: { order_id: hold.order_id, app: 'tiqet' },
      customization: {
        title: 'Tiqet ticket order',
        description: `${hold.quantity} event ticket(s)`,
      },
    }),
  })

  const chapa = await chapaResponse.json().catch(() => ({}))
  const checkoutUrl = chapa?.data?.checkout_url
  if (!chapaResponse.ok || chapa?.status !== 'success' || !checkoutUrl) {
    await admin.rpc('fail_order_payment', {
      p_order_id: hold.order_id,
      p_reason: `Chapa initialization failed (${chapaResponse.status})`,
    })
    return json({ error: chapa?.message ?? 'Could not initialize payment' }, 502)
  }

  const { error: paymentInsertError } = await admin.from('payments').insert({
    order_id: hold.order_id,
    provider: 'chapa',
    merchant_reference: hold.merchant_reference,
    provider_reference: null,
    checkout_url: checkoutUrl,
    amount_minor: hold.amount_minor,
    currency: 'ETB',
    status: 'initiated',
    provider_payload: chapa,
  })

  if (paymentInsertError) {
    await admin.rpc('fail_order_payment', {
      p_order_id: hold.order_id,
      p_reason: 'Could not persist payment initialization',
    })
    return json({ error: 'Could not save payment session' }, 500)
  }

  return json({
    order_id: hold.order_id,
    merchant_reference: hold.merchant_reference,
    checkout_url: checkoutUrl,
    hold_expires_at: hold.hold_expires_at,
  })
})
