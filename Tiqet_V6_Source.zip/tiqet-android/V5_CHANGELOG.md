# Version 0.2.1 (v5)

- Restores the exact v3 ticket launcher mark preferred by the product owner.
- Adds legacy density launcher PNGs for Android 7.0/7.1 (API 24/25).
- Keeps v4 minSdk 24, targetSdk 36, compileSdk 37 and release-signing configuration.
- No backend, authentication, payment, order, or ticket issuance is claimed as implemented.
