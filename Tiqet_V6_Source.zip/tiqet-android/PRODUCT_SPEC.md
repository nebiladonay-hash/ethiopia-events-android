# Tiqet — product and security specification

## Product

One native Android application for buyers and organisers. Users can switch between buyer and organiser views using one account. Organiser event creation is enabled only for verified organisations. Staff check-in permissions are restricted to assigned events.

## Brand and platform

- Brand name: Tiqet
- Red: `#B82035`; ivory: `#F7F1E7`; ink: `#2B2020`
- Preserve the restored red-field/ivory-ticket launcher mark.
- Android min API 24, target API 36, compile API 37.

## Current connected flows

Buyer: Supabase account registration/sign-in, approved live event discovery, event detail, server-side ticket hold and Chapa hosted checkout, issued-ticket retrieval and QR display.

Organiser: organisation verification application, pending/verified status, transactional event submission and first ticket type creation. Verified organisers can use the camera QR scanner on published events; duplicate scans are rejected by the database.

## Transaction invariants

1. Server/database owns inventory, ticket prices and payable totals.
2. `create_order_hold` locks the ticket type row and reserves stock for ten minutes.
3. The payment provider is called only by the Edge Function. Chapa private key is never shipped in Android.
4. A webhook must pass HMAC-SHA256 validation over its raw request body. The backend then independently verifies the transaction with Chapa and checks order reference, amount and ETB currency.
5. `complete_order_payment` is service-role-only, idempotent, and creates tickets only after verified payment.
6. Ticket tokens are cryptographically random and unique; the client cannot mint them.
7. `checkin_ticket` verifies event assignment and performs a single-use state transition. Duplicate scans are rejected.
8. Expired holds and failed payments release reserved stock.

## Backend

Supabase Auth, Postgres and Edge Functions. RLS scopes buyer data to the authenticated buyer, organiser data to the organisation owner and event data to published/approved public listings. Payment completion and failure RPCs are not executable by client roles.

## Remaining release gates

Admin review tooling; event media; publication moderation; full tickets/order detail and refund flows; staff assignment management and offline scanner queue; organiser analytics and payout workflow; data-export/deletion/privacy policy; Amharic; Chapa test-mode end-to-end cases; API 24–36 device testing; signing key and release AAB.
