package et.events.mobile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import et.events.mobile.backend.TiqetApi
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private val OrgRed = Color(0xFFB82035)
private val OrgIvory = Color(0xFFF7F1E7)
private val OrgInk = Color(0xFF2B2020)
private val OrgMuted = Color(0xFF8C7771)

@Composable
fun TiqetOrganizerScreen(api: TiqetApi, onSwitchRole: () -> Unit, onSignOut: () -> Unit) {
    var organisations by remember { mutableStateOf(JSONArray()) }
    var events by remember { mutableStateOf(JSONArray()) }
    var loading by remember { mutableStateOf(true) }
    var working by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var selectedScanEventId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val qrScanner = rememberLauncherForActivityResult(ScanContract()) { scanResult ->
        val token = scanResult.contents
        val eventId = selectedScanEventId
        if (!token.isNullOrBlank() && !eventId.isNullOrBlank()) {
            scope.launch {
                error = ""
                notice = "Checking ticket…"
                try {
                    val result = withContext(Dispatchers.IO) {
                        api.checkInTicket(eventId, token, android.os.Build.MODEL)
                    }
                    notice = when {
                        result.optBoolean("valid") -> "ENTRY APPROVED · Ticket checked in successfully."
                        result.optString("reason") == "already_checked_in" -> "DUPLICATE · This ticket has already been scanned."
                        result.optString("reason") == "ticket_not_found" -> "INVALID · This ticket does not belong to this event."
                        else -> "INVALID · This ticket cannot be used for entry."
                    }
                } catch (exception: Exception) {
                    error = exception.message ?: "Ticket validation failed."
                    notice = ""
                } finally {
                    selectedScanEventId = null
                }
            }
        } else {
            selectedScanEventId = null
        }
    }

    fun refresh() {
        scope.launch {
            loading = true
            try {
                val result = withContext(Dispatchers.IO) {
                    api.fetchMyOrganisations() to api.fetchMyOrganiserEvents()
                }
                organisations = result.first
                events = result.second
                error = ""
            } catch (exception: Exception) {
                error = exception.message ?: "Could not load organiser information."
            } finally { loading = false }
        }
    }

    LaunchedEffect(api) { refresh() }

    val organisation = organisations.optJSONObject(0)
    val organisationStatus = organisation?.optString("status", "") ?: ""
    val verifiedOrganisationId = if (organisationStatus == "verified") organisation?.optString("id") else null

    var organisationName by remember { mutableStateOf("") }
    var legalName by remember { mutableStateOf("") }
    var contactPhone by remember { mutableStateOf("") }
    var eventTitle by remember { mutableStateOf("") }
    var eventDescription by remember { mutableStateOf("") }
    var eventCategory by remember { mutableStateOf("Music") }
    var eventDate by remember { mutableStateOf("") }
    var venueName by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("Addis Ababa") }
    var ticketName by remember { mutableStateOf("Regular") }
    var price by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(OrgIvory).verticalScroll(rememberScrollState()).padding(horizontal = 21.dp)) {
        Spacer(Modifier.height(22.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("TIQET", color = OrgRed, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
            Text("ORGANISER", color = OrgMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        }
        Spacer(Modifier.height(23.dp))
        Text("Organiser workspace", color = OrgInk, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text("Your organisation must be verified before you can create events for sale.", color = OrgMuted, fontSize = 12.sp, lineHeight = 18.sp)
        Spacer(Modifier.height(19.dp))

        if (loading) {
            Text("Loading your organiser status…", color = OrgMuted, fontSize = 13.sp)
        } else if (organisation == null) {
            Text("Apply to organise events", color = OrgInk, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Submit your organisation details. Tiqet will review the application before enabling event publishing.", color = OrgMuted, fontSize = 12.sp, lineHeight = 18.sp)
            Spacer(Modifier.height(14.dp))
            OrgField("Public organisation name", organisationName, { organisationName = it })
            OrgField("Registered / legal name", legalName, { legalName = it })
            OrgField("Contact phone (+251…)", contactPhone, { contactPhone = it }, KeyboardType.Phone)
            Spacer(Modifier.height(12.dp))
            OrgActionButton("Submit verification application", working) {
                if (organisationName.isBlank() || legalName.isBlank() || contactPhone.isBlank()) {
                    error = "Complete all organisation fields first."
                } else {
                    working = true; error = ""; notice = ""
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) { api.submitOrganisationApplication(organisationName, legalName, contactPhone) }
                            notice = "Application submitted. Your status is now pending review."
                            refresh()
                        } catch (exception: Exception) { error = exception.message ?: "Application could not be submitted." }
                        finally { working = false }
                    }
                }
            }
        } else if (organisationStatus == "pending") {
            StatusPanel("Application under review", "${organisation.optString("name")} has been submitted. Event creation will unlock after verification.", "PENDING")
        } else if (organisationStatus == "rejected" || organisationStatus == "suspended") {
            StatusPanel("Organiser access unavailable", organisation.optString("verification_notes", "Contact Tiqet support for the next steps."), organisationStatus.uppercase())
        } else if (verifiedOrganisationId != null) {
            StatusPanel("Organisation verified", "${organisation.optString("name")} is verified and can now submit events for Tiqet review. Listings become public only after approval.", "VERIFIED")
            Spacer(Modifier.height(20.dp))
            Text("Create an event", color = OrgInk, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            OrgField("Event title", eventTitle, { eventTitle = it })
            OrgField("Category", eventCategory, { eventCategory = it })
            OrgField("Description", eventDescription, { eventDescription = it }, singleLine = false)
            OrgField("Date and time in Addis Ababa (YYYY-MM-DD HH:MM)", eventDate, { eventDate = it })
            OrgField("Venue name", venueName, { venueName = it })
            OrgField("Street address", address, { address = it })
            OrgField("City", city, { city = it })
            Spacer(Modifier.height(8.dp))
            Text("First ticket type", color = OrgInk, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            OrgField("Ticket label", ticketName, { ticketName = it })
            OrgField("Price in ETB", price, { price = it.filter { c -> c.isDigit() || c == '.' } }, KeyboardType.Decimal)
            OrgField("Quantity available", quantity, { quantity = it.filter(Char::isDigit) }, KeyboardType.Number)
            Spacer(Modifier.height(12.dp))
            OrgActionButton("Submit event for review", working) {
                val parsedPrice = price.toDoubleOrNull()
                val parsedQuantity = quantity.toIntOrNull()
                val startsAt = try {
                    val inputFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply {
                        isLenient = false
                        timeZone = TimeZone.getTimeZone("Africa/Addis_Ababa")
                    }
                    val parsed: Date = inputFormat.parse(eventDate.trim())
                        ?: throw IllegalArgumentException("Invalid date")
                    SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(parsed)
                } catch (_: Exception) { null }
                if (eventTitle.isBlank() || venueName.isBlank() || startsAt == null || parsedPrice == null || parsedQuantity == null || parsedQuantity < 1 || ticketName.isBlank()) {
                    error = "Check the event title, venue, date format, ticket price and ticket quantity."
                } else {
                    working = true; error = ""; notice = ""
                    scope.launch {
                        try {
                            val submission = withContext(Dispatchers.IO) {
                                api.createEventSubmission(
                                    verifiedOrganisationId, eventTitle, eventDescription, eventCategory,
                                    startsAt, venueName, address, city, ticketName, parsedPrice, parsedQuantity
                                )
                            }
                            if (submission.optString("event_id").isBlank()) {
                                throw IllegalStateException("The server did not confirm the event submission.")
                            }
                            notice = "Event submitted to Tiqet for review. It will appear publicly only after approval."
                            eventTitle = ""; eventDescription = ""; eventDate = ""; venueName = ""; address = ""; price = ""; quantity = ""
                            refresh()
                        } catch (exception: Exception) { error = exception.message ?: "Event could not be submitted." }
                        finally { working = false }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("Your event records", color = OrgInk, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (events.length() == 0) Text("No events created yet.", color = OrgMuted, fontSize = 12.sp)
            for (index in 0 until events.length()) {
                val event = events.optJSONObject(index) ?: continue
                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
                    Text(event.optString("title"), color = OrgInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("${event.optString("status").uppercase()} · ${event.optString("approval_status").uppercase()}", color = OrgRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    if (event.optString("status") == "published" && event.optString("approval_status") == "approved") {
                        Spacer(Modifier.height(7.dp))
                        Button(
                            onClick = {
                                selectedScanEventId = event.optString("id")
                                val options = ScanOptions()
                                    .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                                    .setPrompt("Scan a Tiqet ticket for ${event.optString("title")}")
                                    .setBeepEnabled(true)
                                    .setOrientationLocked(false)
                                qrScanner.launch(options)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = OrgRed)
                        ) { Text("Scan entry QR") }
                    }
                }
            }
        }

        if (error.isNotBlank()) {
            Spacer(Modifier.height(10.dp)); Text(error, color = OrgRed, fontSize = 12.sp, lineHeight = 17.sp)
        }
        if (notice.isNotBlank()) {
            Spacer(Modifier.height(10.dp)); Text(notice, color = OrgInk, fontSize = 12.sp, lineHeight = 17.sp)
        }
        if (!loading) {
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onSwitchRole, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = OrgRed)) { Text("Buyer view") }
                Button(onClick = onSignOut, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = OrgMuted)) { Text("Sign out") }
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun OrgField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        label = { Text(label) },
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 3,
        shape = RoundedCornerShape(11.dp),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType)
    )
}

@Composable
private fun OrgActionButton(text: String, working: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = !working,
        modifier = Modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = OrgRed)
    ) { Text(if (working) "Saving…" else text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun StatusPanel(title: String, description: String, label: String) {
    Column(modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(15.dp)).padding(17.dp)) {
        Text(label, color = OrgRed, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.3.sp)
        Spacer(Modifier.height(7.dp))
        Text(title, color = OrgInk, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(description, color = OrgMuted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}
