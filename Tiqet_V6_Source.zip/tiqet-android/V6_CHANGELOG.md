# Tiqet V6 change log

- Rebranded the application label and interface to Tiqet; retained the approved ticket launcher icon and red/ivory palette.
- Removed sample buyer event listings. Buyer discovery now requests approved/published records from Supabase.
- Added email/password registration and sign-in against Supabase Auth.
- Added Android Keystore AES-GCM encrypted storage for the access and refresh tokens.
- Connected the buyer booking action to the server-side Chapa checkout Edge Function.
- Connected the buyer ticket list to issued ticket records and added QR rendering for random ticket tokens.
- Added organiser application submission, verification-state display, and transactional event and initial ticket-type submission for verified organisations.
- Added a complete initial Postgres schema, RLS policies, transactional inventory holds and event submission, server-only payment completion/failure functions, free-ticket claim RPC, event review submission RPC, and atomic check-in RPC.
- Added Chapa v2 hosted checkout and HMAC-verified webhook functions that independently verify amount, currency and merchant reference before issuing tickets.
- Added configurable Supabase URL and publishable/anon key build fields. No Supabase service-role key or Chapa private key is included in the app.

## Still not release-complete

No full store-ready release is claimed. Requires remote build verification, Supabase project deployment/configuration, Chapa test merchant configuration, sandbox test cases, staff assignment management, refunds, organiser reporting/payouts, moderation tools, media upload, localization and physical-device compatibility testing.

- Event submission is now one database transaction that creates the event and initial ticket type together, avoiding half-created submissions.
- Event date inputs are interpreted in Africa/Addis_Ababa time; buyer listings format event times in EAT.
- Ticket prices preserve cents in display and payment checkout.

- Added a camera-based QR entry scanner for verified organisers with server-validated single-use check-in and duplicate-scan feedback.


## V6.1 authentication callback repair
- Signup now passes `tiqet://auth/callback` as the Supabase redirect target.
- Android registers the Tiqet callback URI and handles it on both cold start and `onNewIntent`.
- The callback validates the Supabase JWT claims and stores the access/refresh tokens using the existing Android Keystore session store.
- The current localhost redirect is not used by the updated signup flow.
