# Tiqet Android — V1 foundation (0.3.0)

Native Android application for event discovery and ticketing in Ethiopia. The original red-and-ivory ticket mark is retained.

## What is connected in this source version

- Buyer/organiser role entry and Supabase email/password sign-up and sign-in.
- Supabase access and refresh tokens encrypted using an Android Keystore AES-GCM key.
- Email signup redirects to the native callback `tiqet://auth/callback`; the Android app stores the verified session and returns to the signed-in experience.
- Live discovery reads only published, approved events from Supabase.
- Event detail selects the lowest-priced ticket type and requests a server-created Chapa hosted checkout; prices retain decimal precision and event times display in Ethiopia Time (EAT).
- Ticket list reads only tickets belonging to the signed-in buyer and displays each issued random token as a QR code. Verified organisers can open the camera scanner for published events; check-in is validated atomically on the server and duplicate scans are rejected.
- Organiser onboarding submits a pending organisation for review. Verified organisers can create an event and its first ticket type in one database transaction, then submit it for review.
- Database transaction functions reserve ticket inventory, verify exact payment values before issuing tickets, and prevent duplicate check-in.
- Chapa v2 checkout and webhook Edge Functions are included. The webhook validates the raw-body HMAC signature and then calls Chapa's verify endpoint before tickets are issued.

## What is not complete yet

This is an active development build, not a production release. The code still needs a remote build and device test after the backend variables are configured. The following work remains: event image upload, event publishing and admin review tools, full order history/refund flows, staff assignment management, offline scanner synchronization, organiser sales and payout reporting, Amharic localisation, privacy/terms/refund pages, and end-to-end provider sandbox tests. Do not sell real tickets until these gates are completed.

## Android platform

- Minimum SDK: API 24 (Android 7.0)
- Target SDK: API 36
- Compile SDK: API 37
- JDK: 17
- Android Gradle Plugin: 9.1.1
- Gradle: 9.3.1
- App version: 0.3.1 (versionCode 5)
- Application ID retained for continuity: `et.events.mobile`

The minSdk declaration is not evidence that every listed Android version has been device-tested. Physical/emulator testing is still required.

## Backend setup (new Supabase project; do not reuse ALTROOM)

1. Create a separate Supabase project for Tiqet.
2. Open SQL Editor and run `supabase/migrations/001_tiqet_core.sql` once.
3. In Supabase, open **Authentication → URL Configuration**. Set the **Site URL** to this native app callback (not `http://localhost`):

   `tiqet://auth/callback`

   Add the same exact value under **Redirect URLs**. Supabase supports a mobile deep-link URI as the Site URL and as an allowed redirect.

   The Android app explicitly sends this callback during signup. The `tiqet` custom scheme is registered in the Android manifest.

4. In GitHub repository settings, add repository **Variables**:
   - `SUPABASE_URL` = the Tiqet project URL.
   - `SUPABASE_ANON_KEY` = the project's publishable/anon key. This client key is expected to be public; never put a service-role key in Android or GitHub variables.
5. Deploy the two Edge Functions from the Supabase CLI:

   ```sh
   supabase functions deploy create-chapa-checkout
   supabase functions deploy chapa-webhook
   ```

6. Add Edge Function secrets in Supabase (never in the Android project):

   ```sh
   supabase secrets set CHAPA_PRIVATE_KEY=your_chapa_test_private_key
   supabase secrets set CHAPA_WEBHOOK_SECRET=your_chapa_webhook_secret
   ```

   Supabase automatically provides `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` to Edge Functions. Keep service-role and Chapa private keys server-side only.

7. In the Chapa dashboard, use **test mode**, configure the webhook URL as:

   `https://YOUR_PROJECT_REF.supabase.co/functions/v1/chapa-webhook`

   Select signature authentication and use the same random value as `CHAPA_WEBHOOK_SECRET`.

8. Commit the updated app ZIP and run the V6 GitHub Actions workflow. If the Supabase repository variables are absent, the APK still compiles but the app displays a backend-not-configured message and cannot sign in or load events.

## Security and transaction model

The database is the source of truth for ticket inventory and prices. The app never decides an order is paid. Checkout initialization is server-side; the webhook verifies its signature and then re-queries Chapa. The completion RPC compares merchant reference, amount and currency, transitions the order once, moves reserved inventory to sold inventory and issues random ticket tokens atomically. Check-in uses a single-use database transition. Chapa private keys and Supabase service-role keys must never be embedded in the Android binary.

## Brand

- Name: **Tiqet**
- Primary red: `#B82035`
- Warm ivory: `#F7F1E7`
- Main text: `#2B2020`
- Original user-approved ticket launcher icon preserved.

## Email delivery and branding

- Supabase's built-in SMTP is for development only: it is restricted to team-authorized recipients and low sending limits.
- To send confirmation emails to arbitrary users, configure a custom SMTP provider. The SMTP sender display name is configured in Supabase as `Tiqet`.
- Without a domain, a temporary small-beta option is a dedicated Gmail mailbox used as the verified sender through Gmail SMTP. This is not a production-grade transactional-email setup; use a domain-authenticated email provider before public launch.
- In Authentication → Emails → Templates, change the confirmation subject to `Confirm your Tiqet account` and preserve the `{{ .ConfirmationURL }}` variable in the button link.
